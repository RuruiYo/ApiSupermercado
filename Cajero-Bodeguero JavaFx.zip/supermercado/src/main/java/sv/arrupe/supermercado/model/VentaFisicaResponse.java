package sv.arrupe.supermercado.model;

public class VentaFisicaResponse {
    private int     iD_Venta;
    private String  fechaHora;
    private double  totalVenta;
    private double  montoRecibido;
    private double  cambio;
    private String  tipoPago;
    private String  nombreCajero;
    private String  nombreCaja;

    public int     getID_Venta()       { return iD_Venta; }
    public String  getFechaHora()      { return fechaHora; }
    public double  getTotalVenta()     { return totalVenta; }
    public double  getMontoRecibido()  { return montoRecibido; }
    public double  getCambio()         { return cambio; }
    public String  getTipoPago()       { return tipoPago; }
    public String  getNombreCajero()   { return nombreCajero; }
    public String  getNombreCaja()     { return nombreCaja; }
}

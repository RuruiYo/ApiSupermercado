package sv.arrupe.supermercado;

public class Launcher {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}

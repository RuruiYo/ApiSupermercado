package sv.arrupe.supermercado.controller;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import sv.arrupe.supermercado.service.ApiService;

import java.util.HashMap;
import java.util.Map;

public class PedidosController {

    @FXML private TableView<JsonObject>              tablaPedidos;
    @FXML private TableColumn<JsonObject, String>    colId;
    @FXML private TableColumn<JsonObject, String>    colCliente;
    @FXML private TableColumn<JsonObject, String>    colFecha;
    @FXML private TableColumn<JsonObject, String>    colTotal;
    @FXML private TableColumn<JsonObject, String>    colEstado;
    @FXML private ProgressIndicator                  spinner;

    private final ObservableList<JsonObject> pedidos = FXCollections.observableArrayList();
    private final ApiService apiService = new ApiService();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(d       -> campo(d.getValue(), "iD_PedidoWeb"));
        colCliente.setCellValueFactory(d  -> campo(d.getValue(), "nombreCliente"));
        colTotal.setCellValueFactory(d -> {
            String v = get(d.getValue(), "totalPedido");
            return new SimpleStringProperty(v != null ? String.format("$%.2f", Double.parseDouble(v)) : "—");
        });
        colFecha.setCellValueFactory(d -> {
            String f = get(d.getValue(), "fechaHoraPedido");
            return new SimpleStringProperty(f != null && f.length() >= 10 ? f.substring(0, 10) : "—");
        });
        colEstado.setCellValueFactory(d -> campo(d.getValue(), "estadoPedido"));
        colEstado.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String val, boolean empty) {
                super.updateItem(val, empty);
                if (empty || val == null) { setText(null); setStyle(""); return; }
                setText(val);
                setStyle(switch (val) {
                    case "PENDIENTE" -> "-fx-text-fill: #fb923c; -fx-font-weight: bold;";
                    case "LISTO"     -> "-fx-text-fill: #4ade80; -fx-font-weight: bold;";
                    case "ENTREGADO" -> "-fx-text-fill: #64748b; -fx-font-weight: bold;";
                    default          -> "-fx-text-fill: #e2e8f0;";
                });
            }
        });

        tablaPedidos.setItems(pedidos);
        cargarDatos();
    }

    @FXML
    private void refrescar() { cargarDatos(); }

    @FXML
    private void marcarListo() { cambiarEstado("LISTO"); }

    @FXML
    private void marcarEntregado() { cambiarEstado("ENTREGADO"); }

    private void cargarDatos() {
        spinner.setVisible(true);
        new Thread(() -> {
            try {
                String json = apiService.get("/pedidosweb");
                JsonArray arr = JsonParser.parseString(json).getAsJsonArray();
                Platform.runLater(() -> {
                    pedidos.clear();
                    for (JsonElement el : arr) pedidos.add(el.getAsJsonObject());
                    spinner.setVisible(false);
                });
            } catch (Exception ex) {
                Platform.runLater(() -> spinner.setVisible(false));
            }
        }).start();
    }

    private void cambiarEstado(String nuevoEstado) {
        JsonObject sel = tablaPedidos.getSelectionModel().getSelectedItem();
        if (sel == null) { alerta("Selecciona un pedido."); return; }
        if ("ENTREGADO".equals(get(sel, "estadoPedido"))) { alerta("Este pedido ya fue entregado."); return; }

        int id = sel.get("iD_PedidoWeb").getAsInt();
        Map<String, String> body = new HashMap<>();
        body.put("estadoPedido", nuevoEstado);

        new Thread(() -> {
            try {
                ApiService.ApiResponse resp = apiService.patch("/pedidosweb/" + id + "/estado", body);
                Platform.runLater(() -> {
                    if (resp.isOk()) cargarDatos();
                    else alerta(resp.getMensajeError());
                });
            } catch (Exception ex) {
                Platform.runLater(() -> alerta("Error: " + ex.getMessage()));
            }
        }).start();
    }

    private SimpleStringProperty campo(JsonObject obj, String key) {
        return new SimpleStringProperty(get(obj, key) != null ? get(obj, key) : "—");
    }

    private String get(JsonObject obj, String key) {
        if (obj == null || !obj.has(key) || obj.get(key).isJsonNull()) return null;
        return obj.get(key).getAsString();
    }

    private void alerta(String msg) {
        Alert a = new Alert(Alert.AlertType.WARNING, msg, ButtonType.OK);
        a.setHeaderText(null); a.showAndWait();
    }
}

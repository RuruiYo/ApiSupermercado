package sv.arrupe.supermercado.controller;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import sv.arrupe.supermercado.service.ApiService;

import java.util.HashMap;
import java.util.Map;

public class PedidosController {

    @FXML private TableView<JsonObject>              tablaPedidos;
    @FXML private TableColumn<JsonObject, String>    colId;
    @FXML private TableColumn<JsonObject, String>    colCliente;
    @FXML private TableColumn<JsonObject, String>    colFecha;
    @FXML private TableColumn<JsonObject, String>    colTotal;
    @FXML private TableColumn<JsonObject, String>    colEstado;
    @FXML private TableColumn<JsonObject, String>    colAcciones;
    @FXML private ProgressIndicator                  spinner;

    private final ObservableList<JsonObject> pedidos = FXCollections.observableArrayList();
    private final ApiService apiService = new ApiService();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(d       -> campo(d.getValue(), "iD_PedidoWeb"));
        colCliente.setCellValueFactory(d  -> campo(d.getValue(), "nombreCliente"));
        colTotal.setCellValueFactory(d -> {
            String v = get(d.getValue(), "totalPedido");
            return new SimpleStringProperty(v != null ? String.format("$%.2f", Double.parseDouble(v)) : "—");
        });
        colFecha.setCellValueFactory(d -> {
            String f = get(d.getValue(), "fechaHoraPedido");
            return new SimpleStringProperty(f != null && f.length() >= 10 ? f.substring(0, 10) : "—");
        });
        colEstado.setCellValueFactory(d -> campo(d.getValue(), "estadoPedido"));
        colEstado.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String val, boolean empty) {
                super.updateItem(val, empty);
                if (empty || val == null) { setText(null); setStyle(""); return; }
                setText(val);
                setStyle(switch (val) {
                    case "PENDIENTE" -> "-fx-text-fill: #fb923c; -fx-font-weight: bold;";
                    case "LISTO"     -> "-fx-text-fill: #4ade80; -fx-font-weight: bold;";
                    case "ENTREGADO" -> "-fx-text-fill: #64748b; -fx-font-weight: bold;";
                    default          -> "-fx-text-fill: #e2e8f0;";
                });
            }
        });

        // Columna de Acciones con botón Ver Detalle
        colAcciones.setCellFactory(col -> new TableCell<>() {
            private final Button btnDetalle = new Button("👁 Detalle");
            {
                btnDetalle.setStyle("-fx-background-color: #1e3a5f; -fx-text-fill: #60a5fa; -fx-font-weight: bold; -fx-cursor: hand; -fx-background-radius: 4; -fx-padding: 4 8; -fx-font-size: 10;");
                btnDetalle.setOnAction(event -> {
                    JsonObject pedido = getTableView().getItems().get(getIndex());
                    mostrarDetallePedido(pedido);
                });
            }
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : btnDetalle);
            }
        });

        tablaPedidos.setItems(pedidos);
        cargarDatos();
    }

    @FXML
    private void refrescar() { cargarDatos(); }

    @FXML
    private void marcarListo() { cambiarEstado("LISTO"); }

    @FXML
    private void marcarEntregado() { cambiarEstado("ENTREGADO"); }

    private void mostrarDetallePedido(JsonObject pedido) {
        // Los detalles ya están incluidos en el objeto pedido
        JsonArray detalles = new JsonArray();

        try {
            // Verificar si el objeto pedido tiene una propiedad "detalles"
            if (pedido.has("detalles") && pedido.get("detalles").isJsonArray()) {
                detalles = pedido.get("detalles").getAsJsonArray();
            }

            mostrarDialogoDetalle(pedido, detalles);
        } catch (Exception ex) {
            alerta("Error al procesar detalles: " + ex.getMessage());
        }
    }

    private void mostrarDialogoDetalle(JsonObject pedido, JsonArray detalles) {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Detalle del Pedido #" + pedido.get("iD_PedidoWeb").getAsInt());
        dialog.setHeaderText("Productos del Pedido");

        VBox content = new VBox(12);
        content.setPadding(new Insets(12));
        content.setStyle("-fx-background-color: #12141c;");

        // Información del pedido
        HBox infoPedido = new HBox(20);
        Label lblCliente = new Label("Cliente: " + get(pedido, "nombreCliente"));
        Label lblTotal = new Label("Total: $" + String.format("%.2f", Double.parseDouble(get(pedido, "totalPedido"))));
        Label lblEstado = new Label("Estado: " + get(pedido, "estadoPedido"));
        lblCliente.setStyle("-fx-text-fill: #e2e8f0; -fx-font-weight: bold;");
        lblTotal.setStyle("-fx-text-fill: #e2e8f0; -fx-font-weight: bold;");
        lblEstado.setStyle("-fx-text-fill: #e2e8f0; -fx-font-weight: bold;");
        infoPedido.getChildren().addAll(lblCliente, lblTotal, lblEstado);

        // Tabla de productos
        TableView<JsonObject> tablaDetalles = new TableView<>();
        tablaDetalles.setPrefHeight(300);
        tablaDetalles.setStyle("-fx-background-color: #181a24; -fx-border-color: #303344;");

        TableColumn<JsonObject, String> colProducto = new TableColumn<>("Producto");
        colProducto.setCellValueFactory(d -> new SimpleStringProperty(get(d.getValue(), "nombreProducto")));
        colProducto.setPrefWidth(250);

        TableColumn<JsonObject, String> colCantidad = new TableColumn<>("Cantidad");
        colCantidad.setCellValueFactory(d -> new SimpleStringProperty(get(d.getValue(), "cantidadPedida")));
        colCantidad.setPrefWidth(80);

        TableColumn<JsonObject, String> colPrecio = new TableColumn<>("Precio");
        colPrecio.setCellValueFactory(d -> {
            String precio = get(d.getValue(), "precioAlMomento");
            return new SimpleStringProperty(precio != null ? "$" + String.format("%.2f", Double.parseDouble(precio)) : "—");
        });
        colPrecio.setPrefWidth(100);

        TableColumn<JsonObject, String> colSubtotal = new TableColumn<>("Subtotal");
        colSubtotal.setCellValueFactory(d -> {
            String cant = get(d.getValue(), "cantidadPedida");
            String precio = get(d.getValue(), "precioAlMomento");
            if (cant != null && precio != null) {
                double subtotal = Integer.parseInt(cant) * Double.parseDouble(precio);
                return new SimpleStringProperty("$" + String.format("%.2f", subtotal));
            }
            return new SimpleStringProperty("—");
        });
        colSubtotal.setPrefWidth(100);

        tablaDetalles.getColumns().addAll(colProducto, colCantidad, colPrecio, colSubtotal);

        ObservableList<JsonObject> items = FXCollections.observableArrayList();
        for (JsonElement el : detalles) items.add(el.getAsJsonObject());
        tablaDetalles.setItems(items);

        content.getChildren().addAll(infoPedido, new Separator(), tablaDetalles);

        dialog.getDialogPane().setContent(content);
        dialog.getDialogPane().setStyle("-fx-background-color: #12141c;");
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.showAndWait();
    }

    private void cargarDatos() {
        spinner.setVisible(true);
        new Thread(() -> {
            try {
                String json = apiService.get("/pedidosweb");
                JsonArray arr = JsonParser.parseString(json).getAsJsonArray();
                Platform.runLater(() -> {
                    pedidos.clear();
                    for (JsonElement el : arr) pedidos.add(el.getAsJsonObject());
                    spinner.setVisible(false);
                });
            } catch (Exception ex) {
                Platform.runLater(() -> spinner.setVisible(false));
            }
        }).start();
    }

    private void cambiarEstado(String nuevoEstado) {
        JsonObject sel = tablaPedidos.getSelectionModel().getSelectedItem();
        if (sel == null) { alerta("Selecciona un pedido."); return; }

        String estadoActual = get(sel, "estadoPedido");

        // Validación: no se puede marcar como ENTREGADO sin antes estar LISTO
        if ("ENTREGADO".equals(nuevoEstado) && !"LISTO".equals(estadoActual)) {
            alerta("El pedido debe estar en estado 'LISTO' antes de marcar como 'ENTREGADO'.");
            return;
        }

        if ("ENTREGADO".equals(estadoActual)) {
            alerta("Este pedido ya fue entregado.");
            return;
        }

        int id = sel.get("iD_PedidoWeb").getAsInt();
        Map<String, String> body = new HashMap<>();
        body.put("estadoPedido", nuevoEstado);

        new Thread(() -> {
            try {
                ApiService.ApiResponse resp = apiService.patch("/pedidosweb/" + id + "/estado", body);
                Platform.runLater(() -> {
                    if (resp.isOk()) cargarDatos();
                    else alerta(resp.getMensajeError());
                });
            } catch (Exception ex) {
                Platform.runLater(() -> alerta("Error: " + ex.getMessage()));
            }
        }).start();
    }

    private SimpleStringProperty campo(JsonObject obj, String key) {
        return new SimpleStringProperty(get(obj, key) != null ? get(obj, key) : "—");
    }

    private String get(JsonObject obj, String key) {
        if (obj == null || !obj.has(key) || obj.get(key).isJsonNull()) return null;
        return obj.get(key).getAsString();
    }

    private void alerta(String msg) {
        Alert a = new Alert(Alert.AlertType.WARNING, msg, ButtonType.OK);
        a.setHeaderText(null); a.showAndWait();
    }
}
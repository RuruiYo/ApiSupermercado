package sv.arrupe.supermercado.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import sv.arrupe.supermercado.HelloApplication;
import sv.arrupe.supermercado.service.ApiService;

import java.io.IOException;

public class MainCajeroController {

    @FXML private Label     lblNombreCajero;
    @FXML private Button    btnVenta;
    @FXML private Button    btnCaja;
    @FXML private Button    btnPedidos;
    @FXML private StackPane contenido;

    private Button btnActivo = null;

    @FXML
    public void initialize() {
        mostrarVenta();
    }

    public void setNombre(String nombre) {
        lblNombreCajero.setText(nombre);
    }

    @FXML private void mostrarVenta()   { cargar("/sv/arrupe/supermercado/view/venta-view.fxml");   setActivo(btnVenta); }
    @FXML private void mostrarCaja()    { cargar("/sv/arrupe/supermercado/view/caja-view.fxml");    setActivo(btnCaja); }
    @FXML private void mostrarPedidos() { cargar("/sv/arrupe/supermercado/view/pedidos-view.fxml"); setActivo(btnPedidos); }

    @FXML
    private void cerrarSesion() {
        Alert a = new Alert(Alert.AlertType.CONFIRMATION, "¿Cerrar sesión?", ButtonType.YES, ButtonType.NO);
        a.setHeaderText(null);
        a.showAndWait().ifPresent(r -> {
            if (r == ButtonType.YES) {
                ApiService.logout();
                try {
                    Stage stage = (Stage) btnVenta.getScene().getWindow();
                    stage.setResizable(false);
                    HelloApplication.mostrarLogin(stage);
                } catch (IOException e) { e.printStackTrace(); }
            }
        });
    }

    private void cargar(String fxml) {
        try {
            javafx.scene.Node node = new FXMLLoader(getClass().getResource(fxml)).load();
            contenido.getChildren().clear();
            contenido.getChildren().add(node);
        } catch (IOException e) { e.printStackTrace(); }
    }

    private void setActivo(Button btn) {
        if (btnActivo != null) btnActivo.setStyle(estiloNavNormal());
        btnActivo = btn;
        btn.setStyle(estiloNavActivo());
    }

    private String estiloNavNormal() {
        return "-fx-background-color: transparent; -fx-text-fill: #94a3b8; -fx-font-size: 13px; -fx-alignment: CENTER_LEFT; -fx-padding: 10 20 10 20; -fx-cursor: hand; -fx-border-width: 0;";
    }

    private String estiloNavActivo() {
        return "-fx-background-color: #1e3228; -fx-text-fill: #4ade80; -fx-font-size: 13px; -fx-font-weight: bold; -fx-alignment: CENTER_LEFT; -fx-padding: 10 20 10 20; -fx-cursor: hand; -fx-border-width: 0;";
    }
}

package sv.arrupe.supermercado.controller;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import sv.arrupe.supermercado.model.LoteResponse;
import sv.arrupe.supermercado.service.ApiService;

import java.util.List;

public class DescartarController {

    // -- Formulario
    @FXML private ComboBox<LoteResponse>  cmbLote;
    @FXML private TextField               txtCantidad;
    @FXML private TextField               txtObservaciones;
    @FXML private Label                   lblDisponible;   // muestra bodega+estante del lote seleccionado
    @FXML private ProgressIndicator       spinnerDescarte;

    // -- Tabla historial de descartes (solo DESCARTE del historial)
    @FXML private TableView<LoteResponse>           tablaLotes;
    @FXML private TableColumn<LoteResponse, String> colId;
    @FXML private TableColumn<LoteResponse, String> colProducto;
    @FXML private TableColumn<LoteResponse, String> colBodega;
    @FXML private TableColumn<LoteResponse, String> colEstante;
    @FXML private TableColumn<LoteResponse, String> colDescartadas;
    @FXML private TableColumn<LoteResponse, String> colVencimiento;
    @FXML private ProgressIndicator                 spinner;

    private final ObservableList<LoteResponse> lotesLista = FXCollections.observableArrayList();
    private final ApiService apiService = new ApiService();

    @FXML
    public void initialize() {
        // Columnas tabla
        colId         .setCellValueFactory(d -> new SimpleStringProperty(String.valueOf(d.getValue().getID_Lote())));
        colProducto   .setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getNombreProducto()));
        colBodega     .setCellValueFactory(d -> new SimpleStringProperty(String.valueOf(d.getValue().getCantidadBodega())));
        colEstante    .setCellValueFactory(d -> new SimpleStringProperty(String.valueOf(d.getValue().getCantidadEstante())));
        colDescartadas.setCellValueFactory(d -> new SimpleStringProperty(String.valueOf(d.getValue().getUnidadesDescartadas())));
        colVencimiento.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getFechaVencimiento()));

        // Color rojo en columna descartadas
        colDescartadas.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String val, boolean empty) {
                super.updateItem(val, empty);
                if (empty || val == null) { setText(null); setStyle(""); return; }
                setText(val);
                setStyle("0".equals(val)
                        ? "-fx-text-fill: #64748b;"
                        : "-fx-text-fill: #ef4444; -fx-font-weight: bold;");
            }
        });

        tablaLotes.setItems(lotesLista);

        // Al seleccionar lote en ComboBox, actualizar disponible
        cmbLote.valueProperty().addListener((obs, old, lote) -> {
            if (lote != null) {
                int disp = lote.getCantidadBodega() + lote.getCantidadEstante();
                lblDisponible.setText("Disponible: " + disp + " unidades (Bodega: "
                        + lote.getCantidadBodega() + " + Estante: " + lote.getCantidadEstante() + ")");
                lblDisponible.setStyle(disp > 0
                        ? "-fx-text-fill: #4ade80; -fx-font-size: 11px;"
                        : "-fx-text-fill: #ef4444; -fx-font-size: 11px;");
            } else {
                lblDisponible.setText("Selecciona un lote");
                lblDisponible.setStyle("-fx-text-fill: #64748b; -fx-font-size: 11px;");
            }
        });

        if (spinnerDescarte != null) spinnerDescarte.setVisible(false);
        cargarDatos();
    }

    @FXML private void refrescar() { cargarDatos(); }

    private void cargarDatos() {
        spinner.setVisible(true);
        new Thread(() -> {
            try {
                List<LoteResponse> lotes = apiService.getLotes();
                Platform.runLater(() -> {
                    spinner.setVisible(false);
                    if (lotes != null) {
                        lotesLista.setAll(lotes);
                        // Solo lotes con unidades disponibles para el ComboBox
                        List<LoteResponse> disponibles = lotes.stream()
                                .filter(l -> l.getCantidadBodega() + l.getCantidadEstante() > 0)
                                .toList();
                        cmbLote.setItems(FXCollections.observableArrayList(disponibles));
                    }
                });
            } catch (Exception ex) {
                Platform.runLater(() -> {
                    spinner.setVisible(false);
                    alerta("Error cargando lotes: " + ex.getMessage());
                });
            }
        }).start();
    }

    @FXML
    private void registrarDescarte() {
        LoteResponse lote = cmbLote.getValue();
        String cantStr    = txtCantidad.getText().trim();
        String obs        = txtObservaciones.getText().trim();

        if (lote == null)     { alerta("Selecciona un lote."); return; }
        if (cantStr.isEmpty()) { alerta("Ingresa la cantidad a descartar."); return; }

        int cantidad;
        try {
            cantidad = Integer.parseInt(cantStr);
            if (cantidad <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            alerta("La cantidad debe ser un número entero mayor a 0."); return;
        }

        int disponible = lote.getCantidadBodega() + lote.getCantidadEstante();
        if (cantidad > disponible) {
            alerta("No hay suficientes unidades. Disponible: " + disponible); return;
        }

        // Confirmación
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                String.format("¿Descartar %d unidades de \"%s\"?\nEsto se registrará como movimiento DESCARTE.",
                        cantidad, lote.getNombreProducto()),
                ButtonType.YES, ButtonType.NO);
        confirm.setHeaderText(null);
        confirm.setTitle("Confirmar Descarte");
        confirm.showAndWait().ifPresent(r -> {
            if (r == ButtonType.YES) enviarDescarte(lote.getID_Lote(), cantidad, obs);
        });
    }

    private void enviarDescarte(int idLote, int cantidad, String obs) {
        if (spinnerDescarte != null) spinnerDescarte.setVisible(true);

        com.google.gson.JsonObject body = new com.google.gson.JsonObject();
        body.addProperty("iD_Lote",       idLote);
        body.addProperty("cantidad",      cantidad);
        body.addProperty("observaciones", obs.isEmpty() ? "Descarte manual" : obs);

        new Thread(() -> {
            try {
                ApiService.ApiResponse resp = apiService.post("/movimientos/descartar", body);
                Platform.runLater(() -> {
                    if (spinnerDescarte != null) spinnerDescarte.setVisible(false);
                    if (resp.isOk()) {
                        info("Descarte registrado correctamente.");
                        limpiarFormulario();
                        cargarDatos();
                    } else {
                        alerta(resp.getMensajeError());
                    }
                });
            } catch (Exception ex) {
                Platform.runLater(() -> {
                    if (spinnerDescarte != null) spinnerDescarte.setVisible(false);
                    alerta("Error de conexión: " + ex.getMessage());
                });
            }
        }).start();
    }

    @FXML
    private void limpiarFormulario() {
        cmbLote.setValue(null);
        txtCantidad.clear();
        txtObservaciones.clear();
        lblDisponible.setText("Selecciona un lote");
        lblDisponible.setStyle("-fx-text-fill: #64748b; -fx-font-size: 11px;");
    }

    private void alerta(String msg) {
        Alert a = new Alert(Alert.AlertType.WARNING, msg, ButtonType.OK);
        a.setHeaderText(null); a.showAndWait();
    }

    private void info(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        a.setHeaderText(null); a.showAndWait();
    }
}
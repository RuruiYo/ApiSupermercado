package sv.arrupe.supermercado.controller;

import com.google.gson.JsonObject;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import sv.arrupe.supermercado.service.ApiService;

import java.util.List;

public class MovimientosController {

    @FXML private TableView<JsonObject>           tablaMovimientos;
    @FXML private TableColumn<JsonObject, String> colId;
    @FXML private TableColumn<JsonObject, String> colTipo;
    @FXML private TableColumn<JsonObject, String> colProducto;
    @FXML private TableColumn<JsonObject, String> colCantidad;
    @FXML private TableColumn<JsonObject, String> colFecha;
    @FXML private TableColumn<JsonObject, String> colUsuario;
    @FXML private ProgressIndicator spinner;

    private final ObservableList<JsonObject> movimientos = FXCollections.observableArrayList();
    private final ApiService apiService = new ApiService();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(d       -> campo(d.getValue(), "iD_Movimiento"));
        colProducto.setCellValueFactory(d -> campo(d.getValue(), "nombreProducto"));
        colCantidad.setCellValueFactory(d -> campo(d.getValue(), "cantidad"));
        colUsuario.setCellValueFactory(d  -> campo(d.getValue(), "nombreUsuario"));
        colFecha.setCellValueFactory(d -> {
            String f = get(d.getValue(), "fechaMovimiento");
            return new SimpleStringProperty(f != null && f.length() >= 10 ? f.substring(0, 10) : "—");
        });

        // Tipo con colores
        colTipo.setCellValueFactory(d -> campo(d.getValue(), "tipoMovimiento"));
        colTipo.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String val, boolean empty) {
                super.updateItem(val, empty);
                if (empty || val == null) { setText(null); setStyle(""); return; }
                setText(val);
                setStyle(switch (val) {
                    case "ENTRADA_LOTE"     -> "-fx-text-fill: #4ade80; -fx-font-weight: bold;";
                    case "TRASLADO_ESTANTE" -> "-fx-text-fill: #60a5fa; -fx-font-weight: bold;";
                    case "DESCARTE"         -> "-fx-text-fill: #ef4444; -fx-font-weight: bold;";
                    case "VENTA"            -> "-fx-text-fill: #fb923c; -fx-font-weight: bold;";
                    default                 -> "-fx-text-fill: #e2e8f0;";
                });
            }
        });

        tablaMovimientos.setItems(movimientos);
        cargarDatos();
    }

    @FXML
    private void refrescar() { cargarDatos(); }

    private void cargarDatos() {
        spinner.setVisible(true);
        new Thread(() -> {
            try {
                List<JsonObject> lista = apiService.getMovimientos();
                Platform.runLater(() -> {
                    movimientos.setAll(lista != null ? lista : List.of());
                    spinner.setVisible(false);
                });
            } catch (Exception ex) {
                Platform.runLater(() -> { spinner.setVisible(false); });
            }
        }).start();
    }

    private SimpleStringProperty campo(JsonObject obj, String key) {
        return new SimpleStringProperty(get(obj, key) != null ? get(obj, key) : "—");
    }

    private String get(JsonObject obj, String key) {
        if (obj == null || !obj.has(key) || obj.get(key).isJsonNull()) return null;
        return obj.get(key).getAsString();
    }
}

package sv.arrupe.supermercado.controller;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import sv.arrupe.supermercado.HelloApplication;
import sv.arrupe.supermercado.service.ApiService;

import java.util.HashMap;
import java.util.Map;

public class LoginController {

    @FXML private TextField     txtCorreo;
    @FXML private PasswordField txtPassword;
    @FXML private Label         lblError;
    @FXML private Button        btnLogin;
    @FXML private ProgressIndicator spinner;

    private final ApiService apiService = new ApiService();

    @FXML
    public void initialize() {
        lblError.setText("");
        spinner.setVisible(false);
    }

    @FXML
    private void iniciarSesion() {
        String correo = txtCorreo.getText().trim();
        String pass   = txtPassword.getText();

        if (correo.isEmpty() || pass.isEmpty()) {
            lblError.setText("Complete todos los campos.");
            return;
        }

        lblError.setText("");
        btnLogin.setDisable(true);
        spinner.setVisible(true);

        new Thread(() -> {
            try {
                Map<String, String> body = new HashMap<>();
                body.put("correo_Usuario", correo);
                body.put("contrasena", pass);

                ApiService.ApiResponse resp = apiService.postPublic("/auth/login", body);

                Platform.runLater(() -> {
                    btnLogin.setDisable(false);
                    spinner.setVisible(false);

                    if (!resp.isOk()) {
                        lblError.setText(ApiService.getMensaje(resp.body));
                        return;
                    }

                    try {
                        JsonObject json = JsonParser.parseString(resp.body).getAsJsonObject();
                        String rol    = json.get("rol").getAsString();
                        String nombre = json.get("nombreCompleto").getAsString();
                        String token  = json.get("token").getAsString();

                        // Solo Cajero y Bodeguero pueden usar esta app
                        if (!rol.equals("Cajero") && !rol.equals("Bodeguero")) {
                            lblError.setText("Acceso denegado. Solo para Cajeros y Bodegueros.");
                            return;
                        }

                        ApiService.setToken(token);
                        Stage stage = (Stage) btnLogin.getScene().getWindow();

                        if ("Cajero".equals(rol)) {
                            HelloApplication.mostrarMainCajero(stage, nombre);
                        } else {
                            HelloApplication.mostrarMainBodeguero(stage, nombre);
                        }

                    } catch (Exception ex) {
                        lblError.setText("Error procesando la respuesta.");
                    }
                });

            } catch (Exception ex) {
                Platform.runLater(() -> {
                    btnLogin.setDisable(false);
                    spinner.setVisible(false);
                    lblError.setText("No se pudo conectar al servidor.");
                });
            }
        }).start();
    }
}

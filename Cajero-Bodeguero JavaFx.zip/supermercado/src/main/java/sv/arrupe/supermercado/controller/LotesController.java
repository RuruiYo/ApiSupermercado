package sv.arrupe.supermercado.controller;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import sv.arrupe.supermercado.model.LoteResponse;
import sv.arrupe.supermercado.model.ProductoResponse;
import sv.arrupe.supermercado.model.ProveedorResponse;
import sv.arrupe.supermercado.model.UbicacionResponse;
import sv.arrupe.supermercado.service.ApiService;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LotesController {

    // -- Tabla
    @FXML private TextField                txtBuscar;
    @FXML private TableView<LoteResponse>  tablaLotes;
    @FXML private TableColumn<LoteResponse, String> colId;
    @FXML private TableColumn<LoteResponse, String> colProducto;
    @FXML private TableColumn<LoteResponse, String> colBodega;
    @FXML private TableColumn<LoteResponse, String> colEstante;
    @FXML private TableColumn<LoteResponse, String> colVencimiento;
    @FXML private TableColumn<LoteResponse, String> colUbicacion;
    @FXML private TableColumn<LoteResponse, String> colPrecio;  // Valor total del lote
    @FXML private ProgressIndicator spinner;

    // -- Formulario
    @FXML private ComboBox<ProductoResponse>  cmbProducto;
    @FXML private ComboBox<ProveedorResponse> cmbProveedor;
    @FXML private ComboBox<UbicacionResponse> cmbUbicacion;
    @FXML private TextField                   txtCodigoLote;
    @FXML private DatePicker                  dpFechaProduccion;
    @FXML private DatePicker                  dpFechaVencimiento;
    @FXML private TextField                   txtCantidad;
    @FXML private Label                       lblFechaIngreso;
    @FXML private ProgressIndicator           spinnerForm;

    private final ObservableList<LoteResponse> lotesLista = FXCollections.observableArrayList();
    private List<LoteResponse>      todosLotes  = new ArrayList<>();
    private List<UbicacionResponse> ubicaciones = new ArrayList<>();
    private final ApiService apiService = new ApiService();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(d          -> new SimpleStringProperty(String.valueOf(d.getValue().getID_Lote())));
        colProducto.setCellValueFactory(d    -> new SimpleStringProperty(d.getValue().getNombreProducto()));
        colBodega.setCellValueFactory(d      -> new SimpleStringProperty(String.valueOf(d.getValue().getCantidadBodega())));
        colEstante.setCellValueFactory(d     -> new SimpleStringProperty(String.valueOf(d.getValue().getCantidadEstante())));
        colVencimiento.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getFechaVencimiento()));
        colUbicacion.setCellValueFactory(d   -> new SimpleStringProperty(d.getValue().getNombreUbicacion() != null ? d.getValue().getNombreUbicacion() : ""));
        // Valor total = CantidadOriginal * PrecioVenta (calculado en la API)
        colPrecio.setCellValueFactory(d      -> new SimpleStringProperty(String.format("$%.2f", d.getValue().getValorTotalLote())));

        colBodega.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String val, boolean empty) {
                super.updateItem(val, empty);
                if (empty || val == null) { setText(null); setStyle(""); return; }
                setText(val);
                setStyle("0".equals(val)
                    ? "-fx-text-fill: #ef4444; -fx-font-weight: bold;"
                    : "-fx-text-fill: #4ade80; -fx-font-weight: bold;");
            }
        });

        tablaLotes.setItems(lotesLista);
        txtBuscar.textProperty().addListener((o, old, val) -> filtrar(val));

        cmbProducto.valueProperty().addListener((obs, oldVal, prod) -> {
            if (prod != null && !ubicaciones.isEmpty()) {
                ubicaciones.stream()
                    .filter(u -> u.getID_Ubicacion() == prod.getID_Ubicacion())
                    .findFirst()
                    .ifPresent(cmbUbicacion::setValue);
            }
        });

        lblFechaIngreso.setText(LocalDate.now().toString());
        if (spinnerForm != null) spinnerForm.setVisible(false);
        cargarDatos();
    }

    @FXML private void refrescar() { cargarDatos(); }

    private void cargarDatos() {
        spinner.setVisible(true);
        new Thread(() -> {
            try {
                List<LoteResponse>      lotes       = apiService.getLotes();
                List<ProductoResponse>  productos   = apiService.getProductos();
                List<ProveedorResponse> proveedores = apiService.getProveedores();
                List<UbicacionResponse> ubicList    = apiService.getUbicaciones();
                Platform.runLater(() -> {
                    todosLotes  = lotes != null ? lotes : new ArrayList<>();
                    ubicaciones = ubicList != null ? ubicList : new ArrayList<>();
                    lotesLista.setAll(todosLotes);
                    spinner.setVisible(false);
                    cmbProducto.setItems(FXCollections.observableArrayList(productos));
                    cmbProveedor.setItems(FXCollections.observableArrayList(
                        proveedores.stream().filter(ProveedorResponse::isEstadoActivo).toList()));
                    cmbUbicacion.setItems(FXCollections.observableArrayList(ubicaciones));
                });
            } catch (Exception ex) {
                Platform.runLater(() -> {
                    spinner.setVisible(false);
                    alerta("Error cargando datos: " + ex.getMessage());
                });
            }
        }).start();
    }

    @FXML
    private void registrarLote() {
        ProductoResponse  prod    = cmbProducto.getValue();
        ProveedorResponse prov    = cmbProveedor.getValue();
        UbicacionResponse ubic    = cmbUbicacion.getValue();
        String            codigo  = txtCodigoLote.getText().trim();
        LocalDate         fprod   = dpFechaProduccion.getValue();
        LocalDate         fvenc   = dpFechaVencimiento.getValue();
        String            cantStr = txtCantidad.getText().trim();

        if (prod == null)      { alerta("Selecciona un producto.");           return; }
        if (prov == null)      { alerta("Selecciona un proveedor.");          return; }
        if (ubic == null)      { alerta("Selecciona una ubicacion.");         return; }
        if (codigo.isEmpty())  { alerta("Ingresa el codigo del lote.");       return; }
        if (fprod == null)     { alerta("Ingresa la fecha de produccion.");   return; }
        if (fprod.isAfter(LocalDate.now()) || fprod.isEqual(LocalDate.now())) {
            alerta("La fecha de produccion debe ser anterior a hoy."); return;
        }
        if (fvenc == null)     { alerta("Ingresa la fecha de vencimiento.");  return; }
        if (!fvenc.isAfter(LocalDate.now())) {
            alerta("La fecha de vencimiento debe ser posterior a hoy."); return;
        }
        if (!fvenc.isAfter(fprod)) {
            alerta("La fecha de vencimiento debe ser posterior a la de produccion."); return;
        }

        int cantidad;
        try {
            cantidad = Integer.parseInt(cantStr);
            if (cantidad <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            alerta("La cantidad debe ser un numero entero mayor a 0."); return;
        }

        if (spinnerForm != null) spinnerForm.setVisible(true);
        final int    idProd      = prod.getID_Producto();
        final int    idProv      = prov.getID_Proveedor();
        final int    idUbic      = ubic.getID_Ubicacion();
        final String sFprod      = fprod.toString();
        final String sFvenc      = fvenc.toString();
        final int    cant        = cantidad;
        final boolean cambiaUbic = prod.getID_Ubicacion() != idUbic;

        new Thread(() -> {
            try {
                if (cambiaUbic) {
                    ApiService.ApiResponse respProd = apiService.actualizarProducto(prod, idUbic);
                    if (!respProd.isOk()) {
                        Platform.runLater(() -> {
                            if (spinnerForm != null) spinnerForm.setVisible(false);
                            alerta("Error actualizando ubicacion: " + respProd.getMensajeError());
                        });
                        return;
                    }
                }
                ApiService.ApiResponse resp = apiService.crearLote(idProd, idProv, codigo, sFprod, sFvenc, cant);
                Platform.runLater(() -> {
                    if (spinnerForm != null) spinnerForm.setVisible(false);
                    if (resp.isOk()) {
                        info("Lote registrado correctamente.");
                        limpiarFormulario();
                        cargarDatos();
                    } else {
                        alerta(resp.getMensajeError());
                    }
                });
            } catch (Exception ex) {
                Platform.runLater(() -> {
                    if (spinnerForm != null) spinnerForm.setVisible(false);
                    alerta("Error de conexion: " + ex.getMessage());
                });
            }
        }).start();
    }

    @FXML
    private void limpiarFormulario() {
        cmbProducto.setValue(null);
        cmbProveedor.setValue(null);
        cmbUbicacion.setValue(null);
        txtCodigoLote.clear();
        dpFechaProduccion.setValue(null);
        dpFechaVencimiento.setValue(null);
        txtCantidad.clear();
        lblFechaIngreso.setText(LocalDate.now().toString());
    }

    private void filtrar(String texto) {
        if (texto == null || texto.isBlank()) { lotesLista.setAll(todosLotes); return; }
        String t = texto.toLowerCase();
        lotesLista.setAll(todosLotes.stream()
            .filter(l -> l.getNombreProducto().toLowerCase().contains(t)).toList());
    }

    private void alerta(String msg) {
        Alert a = new Alert(Alert.AlertType.WARNING, msg, ButtonType.OK);
        a.setHeaderText(null); a.showAndWait();
    }

    private void info(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        a.setHeaderText(null); a.showAndWait();
    }
}

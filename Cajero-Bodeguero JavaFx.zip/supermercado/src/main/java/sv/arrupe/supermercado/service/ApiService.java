package sv.arrupe.supermercado.service;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import org.apache.http.client.methods.*;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import sv.arrupe.supermercado.model.CajaResponse;
import sv.arrupe.supermercado.model.LoteResponse;
import sv.arrupe.supermercado.model.ProductoResponse;
import sv.arrupe.supermercado.model.VentaFisicaResponse;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class ApiService {

    private static final String BASE_URL = "http://localhost:5153/api";
    private static final Gson gson = new Gson();
    private static String token = null;

    public static void setToken(String t) { token = t; }
    public static void logout()           { token = null; }

    public String get(String endpoint) throws IOException {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpGet req = new HttpGet(BASE_URL + endpoint);
            req.setHeader("Content-Type", "application/json");
            if (token != null) req.setHeader("Authorization", "Bearer " + token);
            try (var resp = client.execute(req)) {
                return EntityUtils.toString(resp.getEntity(), StandardCharsets.UTF_8);
            }
        }
    }

    public ApiResponse postPublic(String endpoint, Object body) throws IOException {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost req = new HttpPost(BASE_URL + endpoint);
            req.setHeader("Content-Type", "application/json");
            req.setEntity(new StringEntity(gson.toJson(body), StandardCharsets.UTF_8));
            try (var resp = client.execute(req)) {
                return new ApiResponse(resp.getStatusLine().getStatusCode(),
                        EntityUtils.toString(resp.getEntity(), StandardCharsets.UTF_8));
            }
        }
    }

    public ApiResponse post(String endpoint, Object body) throws IOException {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost req = new HttpPost(BASE_URL + endpoint);
            req.setHeader("Content-Type", "application/json");
            req.setHeader("Authorization", "Bearer " + token);
            req.setEntity(new StringEntity(gson.toJson(body), StandardCharsets.UTF_8));
            try (var resp = client.execute(req)) {
                return new ApiResponse(resp.getStatusLine().getStatusCode(),
                        EntityUtils.toString(resp.getEntity(), StandardCharsets.UTF_8));
            }
        }
    }

    public ApiResponse patch(String endpoint, Object body) throws IOException {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPatch req = new HttpPatch(BASE_URL + endpoint);
            req.setHeader("Content-Type", "application/json");
            req.setHeader("Authorization", "Bearer " + token);
            req.setEntity(new StringEntity(gson.toJson(body), StandardCharsets.UTF_8));
            try (var resp = client.execute(req)) {
                return new ApiResponse(resp.getStatusLine().getStatusCode(),
                        EntityUtils.toString(resp.getEntity(), StandardCharsets.UTF_8));
            }
        }
    }

    public ApiResponse put(String endpoint, Object body) throws IOException {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPut req = new HttpPut(BASE_URL + endpoint);
            req.setHeader("Content-Type", "application/json");
            req.setHeader("Authorization", "Bearer " + token);
            req.setEntity(new StringEntity(gson.toJson(body), StandardCharsets.UTF_8));
            try (var resp = client.execute(req)) {
                return new ApiResponse(resp.getStatusLine().getStatusCode(),
                        EntityUtils.toString(resp.getEntity(), StandardCharsets.UTF_8));
            }
        }
    }

    // ── Métodos de dominio ────────────────────────────────────────────────────
    public List<ProductoResponse> getProductos() throws IOException {
        return gson.fromJson(get("/productos"), new TypeToken<List<ProductoResponse>>(){}.getType());
    }

    public CajaResponse getMiCaja() throws IOException {
        return gson.fromJson(get("/cajas/mi-caja"), CajaResponse.class);
    }

    public List<LoteResponse> getLotes() throws IOException {
        return gson.fromJson(get("/inventariolotes"), new TypeToken<List<LoteResponse>>(){}.getType());
    }

    public List<JsonObject> getMovimientos() throws IOException {
        String json = get("/movimientos");
        return gson.fromJson(json, new TypeToken<List<JsonObject>>(){}.getType());
    }

    public List<JsonObject> getPedidos() throws IOException {
        String json = get("/pedidosweb");
        return gson.fromJson(json, new TypeToken<List<JsonObject>>(){}.getType());
    }

    // ── NUEVO: Ventas físicas ─────────────────────────────────────────────────
    public List<VentaFisicaResponse> getVentasFisicas() throws IOException {
        String json = get("/ventasfisicas");
        return gson.fromJson(json, new TypeToken<List<VentaFisicaResponse>>(){}.getType());
    }

    // ── Proveedores ───────────────────────────────────────────────────────────
    public List<sv.arrupe.supermercado.model.ProveedorResponse> getProveedores() throws IOException {
        return gson.fromJson(get("/proveedores"),
            new TypeToken<List<sv.arrupe.supermercado.model.ProveedorResponse>>(){}.getType());
    }

    // ── Ubicaciones ───────────────────────────────────────────────────────────
    public List<sv.arrupe.supermercado.model.UbicacionResponse> getUbicaciones() throws IOException {
        return gson.fromJson(get("/ubicaciones"),
            new TypeToken<List<sv.arrupe.supermercado.model.UbicacionResponse>>(){}.getType());
    }


    public ApiResponse actualizarProducto(sv.arrupe.supermercado.model.ProductoResponse prod,
                                           int nuevaUbicacion) throws IOException {
        com.google.gson.JsonObject body = new com.google.gson.JsonObject();
        body.addProperty("nombreProducto", prod.getNombreProducto());
        body.addProperty("descripcion",    prod.getDescripcion() != null ? prod.getDescripcion() : "");
        body.addProperty("precioVenta",    prod.getPrecioVenta());
        body.addProperty("imagenUrl",      prod.getImagenUrl() != null ? prod.getImagenUrl() : "");
        body.addProperty("iD_Categoria",   prod.getID_Categoria());
        body.addProperty("iD_Ubicacion",   nuevaUbicacion);
        return put("/productos/" + prod.getID_Producto(), body);
    }

    // ── Crear lote ────────────────────────────────────────────────────────────
    public ApiResponse crearLote(int idProducto, int idProveedor, String codigoLote,
                                  String fechaProduccion, String fechaVencimiento,
                                  int cantidad) throws IOException {
        com.google.gson.JsonObject body = new com.google.gson.JsonObject();
        body.addProperty("codigoLoteFisico", codigoLote);
        body.addProperty("fechaProduccion",  fechaProduccion);
        body.addProperty("fechaVencimiento", fechaVencimiento);
        body.addProperty("cantidadOriginal", cantidad);
        body.addProperty("iD_Producto",      idProducto);
        body.addProperty("iD_Proveedor",     idProveedor);
        return post("/inventariolotes", body);
    }

    public static String getMensaje(String json) {
        if (json == null || json.isBlank()) return "Sin respuesta del servidor.";
        try {
            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
            if (obj.has("mensaje") && !obj.get("mensaje").isJsonNull())
                return obj.get("mensaje").getAsString();
            if (obj.has("errors")) {
                JsonObject errors = obj.getAsJsonObject("errors");
                StringBuilder sb = new StringBuilder();
                for (String k : errors.keySet()) {
                    JsonArray arr = errors.getAsJsonArray(k);
                    for (int i = 0; i < arr.size(); i++) {
                        if (!sb.isEmpty()) sb.append("\n");
                        sb.append(arr.get(i).getAsString());
                    }
                }
                if (!sb.isEmpty()) return sb.toString();
            }
            if (obj.has("title")) return obj.get("title").getAsString();
        } catch (Exception ignored) {
            if (json.length() <= 300) return json;
        }
        return "Error inesperado.";
    }

    public List<sv.arrupe.supermercado.model.MovimientoResponse> getHistorialMovimientos() throws IOException {
        String json = get("/movimientos");
        return gson.fromJson(json, new TypeToken<List<sv.arrupe.supermercado.model.MovimientoResponse>>(){}.getType());
    }

    public static Gson getGson() { return gson; }

    public static class ApiResponse {
        public final int    status;
        public final String body;

        public ApiResponse(int s, String b) { status = s; body = b; }
        public boolean isOk() { return status >= 200 && status < 300; }

        public String getMensajeError() {
            String msg = getMensaje(body);
            return switch (status) {
                case 400 -> "Datos inválidos:\n" + msg;
                case 401 -> "No autorizado:\n" + msg;
                case 403 -> "Sin permisos:\n" + msg;
                case 404 -> "No encontrado:\n" + msg;
                case 500 -> "Error del servidor:\n" + msg;
                default  -> "Error " + status + ":\n" + msg;
            };
        }
    }
}

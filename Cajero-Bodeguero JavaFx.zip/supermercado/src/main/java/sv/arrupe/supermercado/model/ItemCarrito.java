package sv.arrupe.supermercado.model;

public class ItemCarrito {
    private int    idProducto;
    private String nombre;
    private double precioUnitario;
    private int    cantidad;
    private int    stockDisponible;

    public ItemCarrito(int idProducto, String nombre, double precio, int cantidad, int stock) {
        this.idProducto     = idProducto;
        this.nombre         = nombre;
        this.precioUnitario = precio;
        this.cantidad       = cantidad;
        this.stockDisponible = stock;
    }

    public int    getIdProducto()      { return idProducto; }
    public String getNombre()          { return nombre; }
    public double getPrecioUnitario()  { return precioUnitario; }
    public int    getCantidad()        { return cantidad; }
    public void   setCantidad(int c)   { this.cantidad = c; }
    public int    getStockDisponible() { return stockDisponible; }
    public double getSubtotal()        { return precioUnitario * cantidad; }
    public String getSubtotalStr()     { return String.format("$%.2f", getSubtotal()); }
    public String getPrecioStr()       { return String.format("$%.2f", precioUnitario); }
}

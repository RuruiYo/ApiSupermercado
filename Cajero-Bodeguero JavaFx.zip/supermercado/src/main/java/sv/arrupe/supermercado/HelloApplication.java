package sv.arrupe.supermercado;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {

    public static Stage primaryStage;

    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage;
        mostrarLogin(stage);
    }

    public static void mostrarLogin(Stage stage) throws IOException {
        FXMLLoader loader = new FXMLLoader(
            HelloApplication.class.getResource("/sv/arrupe/supermercado/view/login-view.fxml"));
        Scene scene = new Scene(loader.load(), 440, 500);
        stage.setTitle("Supermercado — Iniciar Sesión");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }

    public static void mostrarMainCajero(Stage stage, String nombre) throws IOException {
        FXMLLoader loader = new FXMLLoader(
            HelloApplication.class.getResource("/sv/arrupe/supermercado/view/main-cajero-view.fxml"));
        Scene scene = new Scene(loader.load(), 1280, 760);
        stage.setTitle("Supermercado — Cajero: " + nombre);
        stage.setResizable(true);
        stage.setMinWidth(1000);
        stage.setMinHeight(650);
        stage.setScene(scene);
    }

    public static void mostrarMainBodeguero(Stage stage, String nombre) throws IOException {
        FXMLLoader loader = new FXMLLoader(
            HelloApplication.class.getResource("/sv/arrupe/supermercado/view/main-bodeguero-view.fxml"));
        Scene scene = new Scene(loader.load(), 1280, 760);
        stage.setTitle("Supermercado — Bodeguero: " + nombre);
        stage.setResizable(true);
        stage.setMinWidth(1000);
        stage.setMinHeight(650);
        stage.setScene(scene);
    }

    public static void main(String[] args) {
        launch();
    }
}

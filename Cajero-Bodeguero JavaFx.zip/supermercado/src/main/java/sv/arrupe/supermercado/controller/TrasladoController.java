package sv.arrupe.supermercado.controller;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import sv.arrupe.supermercado.model.LoteResponse;
import sv.arrupe.supermercado.service.ApiService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TrasladoController {

    @FXML private ComboBox<LoteResponse> cmbLote;
    @FXML private Label    lblBodega;
    @FXML private Label    lblEstante;
    @FXML private Label    lblProducto;
    @FXML private TextField txtCantidad;
    @FXML private ProgressIndicator spinner;

    private final ApiService apiService = new ApiService();

    @FXML
    public void initialize() {
        spinner.setVisible(false);
        cargarLotes();

        cmbLote.setOnAction(e -> {
            LoteResponse sel = cmbLote.getValue();
            if (sel != null) {
                lblProducto.setText(sel.getNombreProducto());
                lblBodega.setText("Stock bodega: " + sel.getCantidadBodega());
                lblEstante.setText("Stock estante: " + sel.getCantidadEstante());
            }
        });
    }

    private void cargarLotes() {
        new Thread(() -> {
            try {
                List<LoteResponse> lista = apiService.getLotes();
                Platform.runLater(() -> {
                    if (lista != null) cmbLote.setItems(FXCollections.observableArrayList(lista));
                });
            } catch (Exception ex) {
                Platform.runLater(() -> alerta("Error cargando lotes: " + ex.getMessage()));
            }
        }).start();
    }

    @FXML
    private void realizarTraslado() {
        LoteResponse lote = cmbLote.getValue();
        if (lote == null) { alerta("Selecciona un lote."); return; }

        int cantidad;
        try {
            cantidad = Integer.parseInt(txtCantidad.getText().trim());
            if (cantidad <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            alerta("Ingresa una cantidad válida mayor a 0.");
            return;
        }

        if (cantidad > lote.getCantidadBodega()) {
            alerta("La cantidad supera el stock en bodega (" + lote.getCantidadBodega() + ").");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
            String.format("Trasladar %d unidades de '%s' a estante.\n¿Confirmar?", cantidad, lote.getNombreProducto()),
            ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirmar traslado");
        confirm.setHeaderText(null);
        confirm.showAndWait().ifPresent(r -> {
            if (r == ButtonType.YES) enviarTraslado(lote.getID_Lote(), cantidad);
        });
    }

    private void enviarTraslado(int idLote, int cantidad) {
        spinner.setVisible(true);
        Map<String, Object> body = new HashMap<>();
        body.put("iD_Lote", idLote);
        body.put("cantidad", cantidad);

        new Thread(() -> {
            try {
                ApiService.ApiResponse resp = apiService.post("/movimientos/traslado", body);
                Platform.runLater(() -> {
                    spinner.setVisible(false);
                    if (resp.isOk()) {
                        Alert ok = new Alert(Alert.AlertType.INFORMATION, "✔ Traslado registrado correctamente.", ButtonType.OK);
                        ok.setHeaderText(null); ok.showAndWait();
                        txtCantidad.clear();
                        cmbLote.setValue(null);
                        lblProducto.setText("—");
                        lblBodega.setText("Stock bodega: —");
                        lblEstante.setText("Stock estante: —");
                        cargarLotes();
                    } else {
                        alerta(resp.getMensajeError());
                    }
                });
            } catch (Exception ex) {
                Platform.runLater(() -> { spinner.setVisible(false); alerta("Error: " + ex.getMessage()); });
            }
        }).start();
    }

    private void alerta(String msg) {
        Alert a = new Alert(Alert.AlertType.WARNING, msg, ButtonType.OK);
        a.setHeaderText(null); a.showAndWait();
    }
}

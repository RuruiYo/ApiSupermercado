package sv.arrupe.supermercado.model;

public class CajaResponse {
    private int     iD_Caja;
    private String  nombreCaja;
    private String  nombreCajero;
    private double  saldoInicial;
    private double  totalEntradas;
    private double  totalSalidas;
    private double  saldoActual;
    private boolean estadoActiva;

    public int     getID_Caja()       { return iD_Caja; }
    public String  getNombreCaja()    { return nombreCaja; }
    public String  getNombreCajero()  { return nombreCajero; }
    public double  getSaldoInicial()  { return saldoInicial; }
    public double  getTotalEntradas() { return totalEntradas; }
    public double  getTotalSalidas()  { return totalSalidas; }
    public double  getSaldoActual()   { return saldoActual; }
    public boolean isEstadoActiva()   { return estadoActiva; }
}

package sv.arrupe.supermercado.model;

import java.time.LocalDateTime;

public class MovimientoResponse {
    private int ID_Movimiento;
    private LocalDateTime FechaHora;
    private String TipoMovimiento;
    private int CantidadMovida;
    private String Observaciones;
    private String NombreProducto;
    private String CodigoLote;
    private String NombreUsuario;

    public MovimientoResponse() {}

    public MovimientoResponse(int id, LocalDateTime fecha, String tipo, int cantidad,
                              String observaciones, String producto, String lote, String usuario) {
        this.ID_Movimiento = id;
        this.FechaHora = fecha;
        this.TipoMovimiento = tipo;
        this.CantidadMovida = cantidad;
        this.Observaciones = observaciones;
        this.NombreProducto = producto;
        this.CodigoLote = lote;
        this.NombreUsuario = usuario;
    }

    // Getters y Setters
    public int getID_Movimiento() { return ID_Movimiento; }
    public void setID_Movimiento(int id) { this.ID_Movimiento = id; }

    public LocalDateTime getFechaHora() { return FechaHora; }
    public void setFechaHora(LocalDateTime fecha) { this.FechaHora = fecha; }

    public String getTipoMovimiento() { return TipoMovimiento; }
    public void setTipoMovimiento(String tipo) { this.TipoMovimiento = tipo; }

    public int getCantidadMovida() { return CantidadMovida; }
    public void setCantidadMovida(int cantidad) { this.CantidadMovida = cantidad; }

    public String getObservaciones() { return Observaciones; }
    public void setObservaciones(String observaciones) { this.Observaciones = observaciones; }

    public String getNombreProducto() { return NombreProducto; }
    public void setNombreProducto(String producto) { this.NombreProducto = producto; }

    public String getCodigoLote() { return CodigoLote; }
    public void setCodigoLote(String lote) { this.CodigoLote = lote; }

    public String getNombreUsuario() { return NombreUsuario; }
    public void setNombreUsuario(String usuario) { this.NombreUsuario = usuario; }
}
package sv.arrupe.supermercado.model;

public class ProductoResponse {
    private int    iD_Producto;
    private String sKU_CodigoInterno;
    private String nombreProducto;
    private String descripcion;
    private double precioVenta;
    private int    stock_Bodega_Total;
    private int    stock_Estante_Total;
    private int    stock_Reservado_Total;
    private String imagenUrl;
    private int    iD_Categoria;
    private String nombreCategoria;
    private int    iD_Ubicacion;
    private String nombreUbicacion;

    public int    getID_Producto()         { return iD_Producto; }
    public String getSKU_CodigoInterno()   { return sKU_CodigoInterno; }
    public String getNombreProducto()      { return nombreProducto; }
    public String getDescripcion()         { return descripcion; }
    public double getPrecioVenta()         { return precioVenta; }
    public int    getStock_Bodega_Total()  { return stock_Bodega_Total; }
    public int    getStock_Estante()       { return stock_Estante_Total; }
    public int    getStock_Reservado()     { return stock_Reservado_Total; }
    public String getImagenUrl()           { return imagenUrl; }
    public int    getID_Categoria()        { return iD_Categoria; }
    public String getNombreCategoria()     { return nombreCategoria; }
    public int    getID_Ubicacion()        { return iD_Ubicacion; }
    public String getNombreUbicacion()     { return nombreUbicacion; }

    // Mantiene compatibilidad con codigo existente que llame getUnidadMedida()
    public String getUnidadMedida()        { return null; }

    @Override public String toString() { return nombreProducto; } // para ComboBox
}

package sv.arrupe.supermercado.controller;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import sv.arrupe.supermercado.model.CajaResponse;
import sv.arrupe.supermercado.model.VentaFisicaResponse;
import sv.arrupe.supermercado.service.ApiService;

import java.util.List;

public class CajaController {

    @FXML private Label lblNombreCaja;
    @FXML private Label lblSaldoActual;
    @FXML private Label lblSaldoInicial;
    @FXML private Label lblEntradas;
    @FXML private Label lblSalidas;
    @FXML private Label lblEstado;
    @FXML private ProgressIndicator spinner;

    // Tabla de transacciones (ventas físicas)
    @FXML private TableView<VentaFisicaResponse> tablaTransacciones;
    @FXML private TableColumn<VentaFisicaResponse, String>  colFecha;
    @FXML private TableColumn<VentaFisicaResponse, String>  colTipo;
    @FXML private TableColumn<VentaFisicaResponse, String>  colDescripcion;
    @FXML private TableColumn<VentaFisicaResponse, Double>  colMonto;

    private final ApiService apiService = new ApiService();

    @FXML
    public void initialize() {
        configurarTabla();
        cargarDatos();
    }

    @FXML
    private void refrescar() {
        cargarDatos();
    }

    private void configurarTabla() {
        colFecha      .setCellValueFactory(new PropertyValueFactory<>("fechaHora"));
        colTipo       .setCellValueFactory(new PropertyValueFactory<>("tipoPago"));
        colDescripcion.setCellValueFactory(new PropertyValueFactory<>("nombreCajero"));

        // Columna Monto: formato $0.00
        colMonto.setCellValueFactory(new PropertyValueFactory<>("totalVenta"));
        colMonto.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(Double valor, boolean empty) {
                super.updateItem(valor, empty);
                if (empty || valor == null) {
                    setText(null);
                } else {
                    setText(String.format("$%.2f", valor));
                    setStyle(valor >= 0
                        ? "-fx-text-fill: #4ade80; -fx-font-weight: bold;"
                        : "-fx-text-fill: #ef4444; -fx-font-weight: bold;");
                }
            }
        });
    }

    private void cargarDatos() {
        spinner.setVisible(true);
        lblSaldoActual.setText("...");

        new Thread(() -> {
            try {
                CajaResponse caja          = apiService.getMiCaja();
                List<VentaFisicaResponse> ventas = apiService.getVentasFisicas();

                Platform.runLater(() -> {
                    spinner.setVisible(false);
                    actualizar(caja);
                    tablaTransacciones.getItems().setAll(ventas);
                });
            } catch (Exception ex) {
                Platform.runLater(() -> {
                    spinner.setVisible(false);
                    lblNombreCaja.setText("Sin caja asignada");
                    lblSaldoActual.setText("—");
                });
            }
        }).start();
    }

    private void actualizar(CajaResponse c) {
        if (c == null) {
            lblNombreCaja.setText("Sin caja asignada");
            lblSaldoActual.setText("—");
            return;
        }
        lblNombreCaja .setText(c.getNombreCaja());
        lblSaldoActual.setText(String.format("$%.2f", c.getSaldoActual()));
        lblSaldoInicial.setText(String.format("$%.2f", c.getSaldoInicial()));
        lblEntradas   .setText(String.format("$%.2f", c.getTotalEntradas()));
        lblSalidas    .setText(String.format("$%.2f", c.getTotalSalidas()));

        if (lblEstado != null) {
            lblEstado.setText(c.isEstadoActiva() ? "● Activa" : "● Inactiva");
            lblEstado.setStyle(c.isEstadoActiva()
                ? "-fx-text-fill: #4ade80; -fx-font-weight: bold;"
                : "-fx-text-fill: #ef4444; -fx-font-weight: bold;");
        }
    }
}

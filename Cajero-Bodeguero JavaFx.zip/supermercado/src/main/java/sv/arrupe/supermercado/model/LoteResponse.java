package sv.arrupe.supermercado.model;

public class LoteResponse {
    private int    iD_Lote;
    private String nombreProducto;
    private int    iD_Producto;
    private int    unidadesEnBodega;
    private int    unidadesEnEstante;
    private int    unidadesVendidas;
    private int    unidadesDescartadas;   // NUEVO
    private String fechaVencimiento;
    private String nombreUbicacion;
    private double precioVenta;
    private double valorTotalLote;

    public int    getID_Lote()              { return iD_Lote; }
    public String getNombreProducto()       { return nombreProducto; }
    public int    getID_Producto()          { return iD_Producto; }
    public int    getCantidadBodega()       { return unidadesEnBodega; }
    public int    getCantidadEstante()      { return unidadesEnEstante; }
    public int    getUnidadesVendidas()     { return unidadesVendidas; }
    public int    getUnidadesDescartadas()  { return unidadesDescartadas; }  // NUEVO
    public String getFechaVencimiento() {
        return fechaVencimiento != null && fechaVencimiento.length() >= 10
                ? fechaVencimiento.substring(0, 10) : "-";
    }
    public String getNombreUbicacion()  { return nombreUbicacion; }
    public double getPrecioVenta()      { return precioVenta; }
    public double getValorTotalLote()   { return valorTotalLote; }
    public double getPrecioCompra()     { return precioVenta; } // compatibilidad

    @Override
    public String toString() {
        return String.format("[%d] %s (Bodega: %d, Estante: %d)",
                iD_Lote, nombreProducto, unidadesEnBodega, unidadesEnEstante);
    }
}
package sv.arrupe.supermercado.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import sv.arrupe.supermercado.HelloApplication;
import sv.arrupe.supermercado.service.ApiService;
import java.io.IOException;

public class MainBodegueroController {

    @FXML private Label     lblNombreBodeguero;
    @FXML private Button    btnLotes;
    @FXML private Button    btnTraslado;
    @FXML private Button    btnDescarte;          // antes btnMovimientos
    @FXML private StackPane contenido;

    private Button btnActivo = null;

    @FXML
    public void initialize() { mostrarLotes(); }

    public void setNombre(String nombre) { lblNombreBodeguero.setText(nombre); }

    @FXML private void mostrarLotes()    { cargar("/sv/arrupe/supermercado/view/lotes-view.fxml");    setActivo(btnLotes); }
    @FXML private void mostrarTraslado() { cargar("/sv/arrupe/supermercado/view/traslado-view.fxml"); setActivo(btnTraslado); }
    @FXML private void mostrarDescarte() { cargar("/sv/arrupe/supermercado/view/descartar-view.fxml"); setActivo(btnDescarte); }

    @FXML
    private void cerrarSesion() {
        Alert a = new Alert(Alert.AlertType.CONFIRMATION, "¿Cerrar sesión?", ButtonType.YES, ButtonType.NO);
        a.setHeaderText(null);
        a.showAndWait().ifPresent(r -> {
            if (r == ButtonType.YES) {
                ApiService.logout();
                try {
                    Stage stage = (Stage) btnLotes.getScene().getWindow();
                    stage.setResizable(false);
                    HelloApplication.mostrarLogin(stage);
                } catch (IOException e) { e.printStackTrace(); }
            }
        });
    }

    private void cargar(String fxml) {
        try {
            javafx.scene.Node node = new FXMLLoader(getClass().getResource(fxml)).load();
            contenido.getChildren().setAll(node);
        } catch (IOException e) { e.printStackTrace(); }
    }

    private void setActivo(Button btn) {
        if (btnActivo != null) btnActivo.setStyle(estiloNavNormal());
        btnActivo = btn;
        btn.setStyle(estiloNavActivo());
    }

    private String estiloNavNormal() {
        return "-fx-background-color: transparent; -fx-text-fill: #94a3b8; -fx-font-size: 13px; " +
                "-fx-alignment: CENTER_LEFT; -fx-padding: 10 20 10 20; -fx-cursor: hand; -fx-border-width: 0;";
    }

    private String estiloNavActivo() {
        return "-fx-background-color: #1e2a40; -fx-text-fill: #60a5fa; -fx-font-size: 13px; " +
                "-fx-font-weight: bold; -fx-alignment: CENTER_LEFT; -fx-padding: 10 20 10 20; " +
                "-fx-cursor: hand; -fx-border-width: 0;";
    }
}
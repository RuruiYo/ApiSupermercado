package sv.arrupe.supermercado.model;

public class UbicacionResponse {
    private int    iD_Ubicacion;
    private String nombreUbicacion;
    private int    totalProductos;

    public int    getID_Ubicacion()    { return iD_Ubicacion; }
    public String getNombreUbicacion() { return nombreUbicacion; }
    public int    getTotalProductos()  { return totalProductos; }

    @Override
    public String toString() { return nombreUbicacion; } // para el ComboBox
}

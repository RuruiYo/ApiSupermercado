package sv.arrupe.supermercado.model;

public class ProveedorResponse {
    private int     iD_Proveedor;
    private String  nombreEmpresa;
    private String  contactoAsignado;
    private String  telefono;
    private boolean estadoActivo;

    public int     getID_Proveedor()     { return iD_Proveedor; }
    public String  getNombreEmpresa()    { return nombreEmpresa; }
    public String  getContactoAsignado() { return contactoAsignado; }
    public String  getTelefono()         { return telefono; }
    public boolean isEstadoActivo()      { return estadoActivo; }

    @Override
    public String toString() { return nombreEmpresa; } // para que el ComboBox muestre el nombre
}

package sv.arrupe.supermercado.controller;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import sv.arrupe.supermercado.model.ItemCarrito;
import sv.arrupe.supermercado.model.ProductoResponse;
import sv.arrupe.supermercado.service.ApiService;

import java.util.*;

public class VentaController {

    @FXML private TextField                   txtBuscar;
    @FXML private TableView<ProductoResponse>  tablaProductos;
    @FXML private TableColumn<ProductoResponse, String>  colNombre;
    @FXML private TableColumn<ProductoResponse, String>  colPrecio;
    @FXML private TableColumn<ProductoResponse, Integer> colStock;

    @FXML private TableView<ItemCarrito>       tablaCarrito;
    @FXML private TableColumn<ItemCarrito, String>  cNombre;
    @FXML private TableColumn<ItemCarrito, Integer> cCantidad;
    @FXML private TableColumn<ItemCarrito, String>  cSubtotal;

    @FXML private Label            lblTotal;
    @FXML private Label            lblCambio;
    @FXML private TextField        txtMonto;
    @FXML private ComboBox<String> cmbPago;
    @FXML private ProgressIndicator spinnerVenta;

    private final ObservableList<ProductoResponse> productosLista = FXCollections.observableArrayList();
    private final ObservableList<ItemCarrito>       carritoLista   = FXCollections.observableArrayList();
    private List<ProductoResponse> todosProductos = new ArrayList<>();
    private int    idCajaAsignada = -1;
    private double saldoCaja      = 0.0;   // saldo actual de la caja

    private final ApiService apiService = new ApiService();

    @FXML
    public void initialize() {
        spinnerVenta.setVisible(false);

        // Tabla productos
        colNombre.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue().getNombreProducto()));
        colPrecio.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(String.format("$%.2f", d.getValue().getPrecioVenta())));
        colStock .setCellValueFactory(d -> new javafx.beans.property.SimpleObjectProperty<>(d.getValue().getStock_Estante()));
        tablaProductos.setItems(productosLista);

        // Tabla carrito
        cNombre  .setCellValueFactory(new PropertyValueFactory<>("nombre"));
        cCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        cSubtotal.setCellValueFactory(new PropertyValueFactory<>("subtotalStr"));
        tablaCarrito.setItems(carritoLista);

        // ComboBox tipo pago
        cmbPago.getItems().addAll("Efectivo", "Tarjeta");
        cmbPago.getSelectionModel().select("Efectivo");
        cmbPago.setOnAction(e -> {
            boolean efectivo = "Efectivo".equals(cmbPago.getValue());
            txtMonto.setDisable(!efectivo);
            if (!efectivo) { txtMonto.clear(); lblCambio.setText("$0.00"); }
        });

        txtMonto.textProperty().addListener((o, old, val) -> calcularCambio());
        txtBuscar.textProperty().addListener((o, old, val) -> filtrar(val));

        // Doble click en producto
        tablaProductos.setRowFactory(tv -> {
            TableRow<ProductoResponse> row = new TableRow<>();
            row.setOnMouseClicked(e -> {
                if (e.getClickCount() == 2 && !row.isEmpty())
                    agregarProducto(row.getItem());
            });
            return row;
        });

        cargarDatos();
    }

    private void cargarDatos() {
        new Thread(() -> {
            try {
                List<ProductoResponse> lista = apiService.getProductos();
                String jsonCaja = apiService.get("/cajas/mi-caja");

                int    idCaja = -1;
                double saldo  = 0.0;
                try {
                    JsonObject caja = JsonParser.parseString(jsonCaja).getAsJsonObject();
                    idCaja = caja.get("iD_Caja").getAsInt();
                    saldo  = caja.get("saldoActual").getAsDouble();
                } catch (Exception ignored) {}

                final int    finalId    = idCaja;
                final double finalSaldo = saldo;

                Platform.runLater(() -> {
                    todosProductos = lista != null ? lista : new ArrayList<>();
                    productosLista.setAll(todosProductos);
                    idCajaAsignada = finalId;
                    saldoCaja      = finalSaldo;
                });
            } catch (Exception ex) {
                Platform.runLater(() -> mostrarError("Error cargando productos: " + ex.getMessage()));
            }
        }).start();
    }

    @FXML
    private void agregarSeleccionado() {
        ProductoResponse sel = tablaProductos.getSelectionModel().getSelectedItem();
        if (sel != null) agregarProducto(sel);
    }

    private void agregarProducto(ProductoResponse p) {
        if (p.getStock_Estante() <= 0) { mostrarError("Sin stock: " + p.getNombreProducto()); return; }
        for (ItemCarrito item : carritoLista) {
            if (item.getIdProducto() == p.getID_Producto()) {
                if (item.getCantidad() >= p.getStock_Estante()) { mostrarError("Stock máximo alcanzado."); return; }
                item.setCantidad(item.getCantidad() + 1);
                carritoLista.set(carritoLista.indexOf(item), item);
                actualizarTotal();
                return;
            }
        }
        carritoLista.add(new ItemCarrito(
                p.getID_Producto(), p.getNombreProducto(), p.getPrecioVenta(), 1, p.getStock_Estante()));
        actualizarTotal();
    }

    @FXML private void quitarSeleccionado() {
        ItemCarrito sel = tablaCarrito.getSelectionModel().getSelectedItem();
        if (sel != null) { carritoLista.remove(sel); actualizarTotal(); }
    }

    @FXML private void limpiarCarrito() {
        carritoLista.clear(); actualizarTotal(); txtMonto.clear();
    }

    @FXML
    private void procesarVenta() {
        if (carritoLista.isEmpty()) { mostrarError("El carrito está vacío."); return; }
        if (idCajaAsignada == -1)   { mostrarError("No tienes una caja asignada."); return; }

        String tipoPago = cmbPago.getValue();
        double total    = carritoLista.stream().mapToDouble(ItemCarrito::getSubtotal).sum();
        double monto    = total;

        if ("Efectivo".equals(tipoPago)) {
            try {
                monto = Double.parseDouble(txtMonto.getText().trim());
            } catch (NumberFormatException e) {
                mostrarError("Ingresa un monto válido."); return;
            }

            if (monto < total) {
                mostrarError("El monto recibido es menor al total ($" + String.format("%.2f", total) + ").");
                return;
            }

            // VALIDACION: el monto recibido no puede superar el saldo de la caja
            // porque si no, no hay con qué dar el cambio
            double cambio = monto - total;
            if (cambio > saldoCaja) {
                mostrarError(String.format(
                        "No hay suficiente saldo en caja para dar el cambio.\n" +
                                "Cambio requerido: $%.2f\n" +
                                "Saldo en caja:    $%.2f\n\n" +
                                "Pide un monto menor o usa tarjeta.", cambio, saldoCaja));
                return;
            }
        }

        double finalMonto = monto;
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                String.format("Total: $%.2f\nTipo: %s\n¿Confirmar venta?", total, tipoPago),
                ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirmar Venta");
        confirm.setHeaderText(null);
        confirm.showAndWait().ifPresent(r -> {
            if (r == ButtonType.YES) enviarVenta(tipoPago, finalMonto);
        });
    }

    private void enviarVenta(String tipoPago, double monto) {
        spinnerVenta.setVisible(true);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("iD_Caja",       idCajaAsignada);
        body.put("tipoPago",      tipoPago);
        body.put("montoRecibido", monto);

        List<Map<String, Object>> detalles = new ArrayList<>();
        for (ItemCarrito item : carritoLista) {
            Map<String, Object> d = new HashMap<>();
            d.put("iD_Producto", item.getIdProducto());
            d.put("cantidad",    item.getCantidad());
            detalles.add(d);
        }
        body.put("detalles", detalles);

        new Thread(() -> {
            try {
                ApiService.ApiResponse resp = apiService.post("/ventasfisicas", body);
                Platform.runLater(() -> {
                    spinnerVenta.setVisible(false);
                    if (resp.isOk()) {
                        double total  = carritoLista.stream().mapToDouble(ItemCarrito::getSubtotal).sum();
                        double cambio = "Efectivo".equals(tipoPago) ? monto - total : 0;
                        Alert ok = new Alert(Alert.AlertType.INFORMATION,
                                String.format("✔ Venta registrada\nCambio: $%.2f", cambio), ButtonType.OK);
                        ok.setTitle("Éxito"); ok.setHeaderText(null); ok.showAndWait();
                        carritoLista.clear();
                        actualizarTotal();
                        txtMonto.clear();
                        cargarDatos(); // refresca saldo de caja
                    } else {
                        mostrarError(resp.getMensajeError());
                    }
                });
            } catch (Exception ex) {
                Platform.runLater(() -> {
                    spinnerVenta.setVisible(false);
                    mostrarError("Error: " + ex.getMessage());
                });
            }
        }).start();
    }

    private void filtrar(String texto) {
        if (texto == null || texto.isBlank()) { productosLista.setAll(todosProductos); return; }
        String t = texto.toLowerCase();
        productosLista.setAll(todosProductos.stream()
                .filter(p -> p.getNombreProducto().toLowerCase().contains(t)).toList());
    }

    private void actualizarTotal() {
        double total = carritoLista.stream().mapToDouble(ItemCarrito::getSubtotal).sum();
        lblTotal.setText(String.format("$%.2f", total));
        calcularCambio();
    }

    private void calcularCambio() {
        if (!"Efectivo".equals(cmbPago.getValue())) return;
        try {
            double monto  = Double.parseDouble(txtMonto.getText().trim());
            double total  = carritoLista.stream().mapToDouble(ItemCarrito::getSubtotal).sum();
            double cambio = monto - total;

            if (cambio < 0) {
                lblCambio.setText("Insuficiente");
                lblCambio.setStyle("-fx-text-fill: #ef4444;");
            } else if (cambio > saldoCaja) {
                // Cambio posible pero la caja no tiene suficiente
                lblCambio.setText(String.format("$%.2f ⚠ sin saldo", cambio));
                lblCambio.setStyle("-fx-text-fill: #fb923c;");
            } else {
                lblCambio.setText(String.format("$%.2f", cambio));
                lblCambio.setStyle("-fx-text-fill: #60a5fa;");
            }
        } catch (NumberFormatException e) {
            lblCambio.setText("$0.00");
            lblCambio.setStyle("-fx-text-fill: #60a5fa;");
        }
    }

    private void mostrarError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        a.setHeaderText(null); a.showAndWait();
    }
}
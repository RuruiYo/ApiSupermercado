module sv.arrupe.supermercado {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires org.apache.httpcomponents.httpclient;
    requires org.apache.httpcomponents.httpcore;

    opens sv.arrupe.supermercado to javafx.fxml;
    opens sv.arrupe.supermercado.controller to javafx.fxml;
    opens sv.arrupe.supermercado.model to com.google.gson, javafx.fxml;

    exports sv.arrupe.supermercado;
    exports sv.arrupe.supermercado.model;
}
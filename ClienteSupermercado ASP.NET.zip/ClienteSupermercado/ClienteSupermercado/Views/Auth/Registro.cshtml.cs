using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ClienteSupermercado.Views.Auth
{
    public class RegistroModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

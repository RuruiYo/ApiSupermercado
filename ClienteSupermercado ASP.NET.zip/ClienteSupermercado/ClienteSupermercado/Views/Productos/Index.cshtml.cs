using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ClienteSupermercado.Views.Productos
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

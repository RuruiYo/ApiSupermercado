using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ClienteSupermercado.Views.Productos
{
    public class CarritoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

namespace ClienteSupermercado.Models;

public class LoginVM { public string Correo { get; set; } = ""; public string Contrasena { get; set; } = ""; }

public class RegistroVM
{
    public string NombreCompleto  { get; set; } = "";
    public string Correo_Usuario  { get; set; } = "";
    public string Contrasena      { get; set; } = "";
    public string Telefono        { get; set; } = "";
    public string Direccion       { get; set; } = "";
}

public class ProductoVM
{
    public int     ID_Producto         { get; set; }
    public string  NombreProducto      { get; set; } = "";
    public string  NombreCategoria     { get; set; } = "";
    public decimal PrecioVenta         { get; set; }
    public int     Stock_Estante_Total { get; set; }
    public string? ImagenUrl           { get; set; }
}

public class ItemCarritoVM
{
    public int     ID_Producto    { get; set; }
    public string  Nombre         { get; set; } = "";
    public decimal PrecioUnitario { get; set; }
    public int     Cantidad       { get; set; }
    public decimal Subtotal       => PrecioUnitario * Cantidad;
}


public class PedidoVM
{
    public int ID_PedidoWeb { get; set; }
    public string NombreCliente { get; set; } = "";
    public DateTime FechaHoraPedido { get; set; }
    public decimal TotalPedido { get; set; }
    public string EstadoPedido { get; set; } = "";
}
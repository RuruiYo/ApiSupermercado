﻿using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace ClienteSupermercado.Services;

public class ApiService
{
    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _ctx;
    private readonly string _base;

    public ApiService(IHttpClientFactory factory, IConfiguration config, IHttpContextAccessor ctx)
    {
        _http = factory.CreateClient();
        _ctx = ctx;
        _base = config["ApiSettings:BaseUrl"]!;
    }

    private void AgregarToken()
    {
        var token = _ctx.HttpContext?.Session.GetString("token");
        _http.DefaultRequestHeaders.Authorization = token != null
            ? new AuthenticationHeaderValue("Bearer", token)
            : null;
    }

    public async Task<HttpResponseMessage> GetAsync(string endpoint)
    {
        AgregarToken();
        return await _http.GetAsync(_base + endpoint);
    }

    public async Task<HttpResponseMessage> PostAsync(string endpoint, object body)
    {
        AgregarToken();
        var json = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");
        return await _http.PostAsync(_base + endpoint, json);
    }
}
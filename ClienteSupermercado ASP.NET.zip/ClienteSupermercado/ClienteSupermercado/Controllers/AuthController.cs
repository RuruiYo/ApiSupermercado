﻿using ClienteSupermercado.Models;
using ClienteSupermercado.Services;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace ClienteSupermercado.Controllers;

public class AuthController : Controller
{
    private readonly ApiService _api;
    public AuthController(ApiService api) { _api = api; }

    [HttpGet] public IActionResult Login() => View();
    [HttpGet] public IActionResult Registro() => View();

    [HttpPost]
    public async Task<IActionResult> Login(LoginVM vm)
    {
        var resp = await _api.PostAsync("/auth/login", new
        {
            correo_Usuario = vm.Correo,
            contrasena = vm.Contrasena
        });

        if (!resp.IsSuccessStatusCode)
        { ViewBag.Error = "Correo o contraseña incorrectos."; return View(vm); }

        var json = await resp.Content.ReadAsStringAsync();
        var doc = JsonDocument.Parse(json).RootElement;

        // La API devuelve "Rol" con R mayúscula
        string rol = "";
        if (doc.TryGetProperty("Rol", out var rp)) rol = rp.GetString() ?? "";
        else if (doc.TryGetProperty("rol", out var rp2)) rol = rp2.GetString() ?? "";

        if (rol != "Cliente")
        { ViewBag.Error = "Acceso denegado. Solo para clientes."; return View(vm); }

        HttpContext.Session.SetString("token", doc.TryGetProperty("token", out var t) ? t.GetString()! : "");
        HttpContext.Session.SetString("nombre", doc.TryGetProperty("nombreCompleto", out var n) ? n.GetString()! : "");
        return RedirectToAction("Index", "Productos");
    }
    [HttpPost]
    public async Task<IActionResult> Registro(RegistroVM vm)
    {
        var resp = await _api.PostAsync("/auth/registro", new
        {
            nombreCompleto = vm.NombreCompleto,
            correo_Usuario = vm.Correo_Usuario,
            contrasena = vm.Contrasena
        });

        if (!resp.IsSuccessStatusCode)
        {
            try
            {
                var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync()).RootElement;
                ViewBag.Error = doc.TryGetProperty("mensaje", out var m) ? m.GetString() : "Error al crear la cuenta.";
            }
            catch { ViewBag.Error = "Error al crear la cuenta."; }
            return View(vm);
        }
        TempData["Ok"] = "Cuenta creada. Inicia sesión.";
        return RedirectToAction("Login");
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Login");
    }
}
using ClienteSupermercado.Models;
using ClienteSupermercado.Services;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace ClienteSupermercado.Controllers;

public class ProductosController : Controller
{
    private readonly ApiService _api;
    public ProductosController(ApiService api) { _api = api; }

    public async Task<IActionResult> Index(string? buscar, string? categoria)
    {
        if (HttpContext.Session.GetString("token") == null)
            return RedirectToAction("Login", "Auth");

        var resp = await _api.GetAsync("/productos/catalogo");
        var json = await resp.Content.ReadAsStringAsync();
        var lista = JsonSerializer.Deserialize<List<ProductoVM>>(json,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new();

        // Filtro buscar
        if (!string.IsNullOrWhiteSpace(buscar))
            lista = lista.Where(p => p.NombreProducto.Contains(buscar, StringComparison.OrdinalIgnoreCase)).ToList();

        // Filtro categoría
        if (!string.IsNullOrWhiteSpace(categoria) && categoria != "Todas")
            lista = lista.Where(p => p.NombreCategoria == categoria).ToList();

        // Obtener categorías únicas para el filtro
        var todasCategorias = JsonSerializer.Deserialize<List<ProductoVM>>(
            await (await _api.GetAsync("/productos/catalogo")).Content.ReadAsStringAsync(),
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new();
        var categorias = todasCategorias.Select(p => p.NombreCategoria).Distinct().OrderBy(c => c).ToList();

        ViewBag.Buscar     = buscar;
        ViewBag.Categoria  = categoria;
        ViewBag.Categorias = categorias;
        ViewBag.Nombre     = HttpContext.Session.GetString("nombre");

        // Cantidad items en carrito para el badge
        var carrito = ObtenerCarrito();
        ViewBag.CarritoCant = carrito.Sum(i => i.Cantidad);

        return View(lista);
    }

    // AJAX: agregar al carrito sin recargar página
    [HttpPost]
    public IActionResult AgregarCarritoAjax([FromBody] AgregarCarritoRequest req)
    {
        var carrito = ObtenerCarrito();
        var item = carrito.FirstOrDefault(i => i.ID_Producto == req.Id);
        if (item != null)
            item.Cantidad += req.Cantidad;
        else
            carrito.Add(new ItemCarritoVM
            {
                ID_Producto    = req.Id,
                Nombre         = req.Nombre,
                PrecioUnitario = req.Precio,
                Cantidad       = req.Cantidad
            });
        GuardarCarrito(carrito);

        return Json(new {
            ok      = true,
            total   = carrito.Sum(i => i.Cantidad),
            mensaje = $"{req.Nombre} agregado al carrito"
        });
    }

    // POST original (compatibilidad)
    [HttpPost]
    public IActionResult AgregarCarrito(int id, string nombre, decimal precio, int cantidad)
    {
        var carrito = ObtenerCarrito();
        var item = carrito.FirstOrDefault(i => i.ID_Producto == id);
        if (item != null) item.Cantidad += cantidad;
        else carrito.Add(new ItemCarritoVM { ID_Producto = id, Nombre = nombre, PrecioUnitario = precio, Cantidad = cantidad });
        GuardarCarrito(carrito);
        return RedirectToAction("Index");
    }

    public IActionResult Carrito()
    {
        if (HttpContext.Session.GetString("token") == null)
            return RedirectToAction("Login", "Auth");
        ViewBag.Nombre = HttpContext.Session.GetString("nombre");
        return View(ObtenerCarrito());
    }

    [HttpPost]
    public IActionResult QuitarItem(int id)
    {
        var carrito = ObtenerCarrito();
        carrito.RemoveAll(i => i.ID_Producto == id);
        GuardarCarrito(carrito);
        return RedirectToAction("Carrito");
    }

    private List<ItemCarritoVM> ObtenerCarrito()
    {
        var json = HttpContext.Session.GetString("carrito");
        return json == null ? new() : JsonSerializer.Deserialize<List<ItemCarritoVM>>(json)!;
    }

    private void GuardarCarrito(List<ItemCarritoVM> c) =>
        HttpContext.Session.SetString("carrito", JsonSerializer.Serialize(c));
}

public class AgregarCarritoRequest
{
    public int     Id       { get; set; }
    public string  Nombre   { get; set; } = "";
    public decimal Precio   { get; set; }
    public int     Cantidad { get; set; }
}

﻿using ClienteSupermercado.Models;
using ClienteSupermercado.Services;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace ClienteSupermercado.Controllers;

public class PedidosController : Controller
{
    private readonly ApiService _api;
    public PedidosController(ApiService api) { _api = api; }

    public async Task<IActionResult> Index()
    {
        if (HttpContext.Session.GetString("token") == null) return RedirectToAction("Login", "Auth");
        ViewBag.Nombre = HttpContext.Session.GetString("nombre");

        var resp = await _api.GetAsync("/pedidosweb/mispedidos");
        var json = await resp.Content.ReadAsStringAsync();
        var lista = JsonSerializer.Deserialize<List<PedidoVM>>(json,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new();
        return View(lista);
    }

    [HttpPost]
    public async Task<IActionResult> Confirmar()
    {
        if (HttpContext.Session.GetString("token") == null) return RedirectToAction("Login", "Auth");

        var carritoJson = HttpContext.Session.GetString("carrito");
        var carrito = carritoJson == null ? new List<ItemCarritoVM>()
            : JsonSerializer.Deserialize<List<ItemCarritoVM>>(carritoJson)!;

        if (!carrito.Any()) { TempData["Error"] = "El carrito está vacío."; return RedirectToAction("Carrito", "Productos"); }

        var detalles = carrito.Select(i => new { ID_Producto = i.ID_Producto, CantidadPedida = i.Cantidad }).ToList();
        var resp = await _api.PostAsync("/pedidosweb", new { Detalles = detalles });

        if (!resp.IsSuccessStatusCode)
        { TempData["Error"] = "Error al confirmar el pedido."; return RedirectToAction("Carrito", "Productos"); }

        HttpContext.Session.Remove("carrito");
        TempData["Ok"] = "¡Pedido confirmado! Te avisaremos cuando esté listo.";
        return RedirectToAction("Index");
    }
}
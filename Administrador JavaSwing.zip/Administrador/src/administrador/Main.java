package administrador;

import com.formdev.flatlaf.FlatDarkLaf;
import administrador.ui.MainFrame;
import administrador.ui.panels.LoginPanel;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        // FlatLaf: aplicar ANTES de crear cualquier ventana
        try {
            FlatDarkLaf.setup();
            // Ajustes finos de FlatLaf
            UIManager.put("Button.arc", 8);
            UIManager.put("Component.arc", 8);
            UIManager.put("TextComponent.arc", 6);
            UIManager.put("ScrollBar.thumbArc", 999);
            UIManager.put("ScrollBar.width", 8);
            UIManager.put("ScrollBar.trackColor", new Color(24, 26, 36));
            UIManager.put("ScrollBar.thumbColor", new Color(60, 65, 85));
            UIManager.put("Table.selectionBackground", new Color(45, 55, 72));
            UIManager.put("Table.selectionForeground", Color.WHITE);
        } catch (Exception e) {
            // Fallback si no está el JAR de FlatLaf
            try {
                UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
            } catch (Exception ignored) {}
        }

        SwingUtilities.invokeLater(() -> {
            JFrame loginFrame = new JFrame("Supermercado — Iniciar Sesión");
            loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            loginFrame.setSize(480, 520);
            loginFrame.setLocationRelativeTo(null);
            loginFrame.setResizable(false);

            loginFrame.add(new LoginPanel(adminName -> {
                loginFrame.dispose();
                new MainFrame(adminName).setVisible(true);
            }));

            loginFrame.setVisible(true);
        });
    }
}

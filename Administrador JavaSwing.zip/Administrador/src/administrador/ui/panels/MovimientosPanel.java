package administrador.ui.panels;

import com.google.gson.reflect.TypeToken;
import administrador.models.MovimientoDTO;
import administrador.services.ApiClient;
import administrador.ui.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class MovimientosPanel extends JPanel {

    private final DefaultTableModel modelo;
    private final JTable tabla;
    private final JTextField txtBuscar;
    private List<MovimientoDTO> movimientos = new ArrayList<>();

    public MovimientosPanel() {
        setLayout(new BorderLayout());
        setBackground(UIUtils.BG_PANEL);

        // ── TOOLBAR ───────────────────────────────────────────────────────────
        JPanel toolbar = new JPanel(new BorderLayout());
        toolbar.setBackground(UIUtils.BG_PANEL);
        toolbar.setBorder(new EmptyBorder(18, 24, 12, 24));

        JLabel titulo = new JLabel("Historial de Movimientos");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(UIUtils.TEXT_PRIMARY);

        JPanel derecha = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        derecha.setOpaque(false);

        txtBuscar = UIUtils.crearTextField("Buscar producto, tipo...");
        txtBuscar.setPreferredSize(new Dimension(220, 34));
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override public void keyReleased(java.awt.event.KeyEvent e) { filtrar(txtBuscar.getText()); }
        });

        // Filtro por tipo
        JComboBox<String> cmbTipo = new JComboBox<>(new String[]{
            "Todos", "ENTRADA_LOTE", "TRASLADO_ESTANTE", "DESCARTE", "VENTA"
        });
        cmbTipo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cmbTipo.setBackground(UIUtils.BG_INPUT);
        cmbTipo.setForeground(UIUtils.TEXT_PRIMARY);
        cmbTipo.setPreferredSize(new Dimension(160, 34));
        cmbTipo.addActionListener(e -> {
            String sel = (String) cmbTipo.getSelectedItem();
            if ("Todos".equals(sel)) rellenarTabla(movimientos);
            else {
                List<MovimientoDTO> f = movimientos.stream()
                        .filter(m -> m.tipoMovimiento.equals(sel)).toList();
                rellenarTabla(f);
            }
        });

        JButton btnRefresh = UIUtils.crearBoton("↺ Actualizar", UIUtils.BORDER_COLOR, UIUtils.TEXT_LABEL);
        btnRefresh.addActionListener(e -> { cmbTipo.setSelectedIndex(0); cargarDatos(); });

        derecha.add(txtBuscar);
        derecha.add(cmbTipo);
        derecha.add(btnRefresh);

        toolbar.add(titulo, BorderLayout.WEST);
        toolbar.add(derecha, BorderLayout.EAST);

        // ── LEYENDA ───────────────────────────────────────────────────────────
        JPanel leyenda = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 4));
        leyenda.setBackground(UIUtils.BG_CARD);
        leyenda.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, UIUtils.BORDER_COLOR));
        leyenda.add(crearLeyenda("● ENTRADA_LOTE", UIUtils.GREEN));
        leyenda.add(crearLeyenda("● TRASLADO_ESTANTE", UIUtils.BLUE));
        leyenda.add(crearLeyenda("● DESCARTE", UIUtils.RED));
        leyenda.add(crearLeyenda("● VENTA", UIUtils.ORANGE));

        // ── TABLA ─────────────────────────────────────────────────────────────
        String[] cols = {"ID", "Fecha/Hora", "Tipo", "Cantidad", "Producto", "Lote", "Responsable", "Observaciones"};
        modelo = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
            @Override public Class<?> getColumnClass(int c) {
                return c == 0 || c == 3 ? Integer.class : String.class;
            }
        };

        tabla = new JTable(modelo);
        UIUtils.estilizarTabla(tabla);
        tabla.getColumnModel().getColumn(2).setCellRenderer(UIUtils.tipoMovimientoRenderer());

        tabla.getColumnModel().getColumn(0).setMaxWidth(50);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(150);
        tabla.getColumnModel().getColumn(2).setPreferredWidth(150);
        tabla.getColumnModel().getColumn(3).setMaxWidth(80);
        tabla.getColumnModel().getColumn(4).setPreferredWidth(160);
        tabla.getColumnModel().getColumn(5).setPreferredWidth(100);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIUtils.BORDER_COLOR));
        scroll.getViewport().setBackground(UIUtils.BG_DARK);

        // Status
        JPanel statusBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 4));
        statusBar.setBackground(UIUtils.BG_CARD);
        statusBar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIUtils.BORDER_COLOR));
        JLabel lblTotal = new JLabel("Total: 0 movimientos");
        lblTotal.setForeground(UIUtils.TEXT_MUTED);
        lblTotal.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        statusBar.add(lblTotal);
        modelo.addTableModelListener(e2 -> lblTotal.setText("Total: " + modelo.getRowCount() + " movimientos"));

        JPanel center = new JPanel(new BorderLayout());
        center.add(leyenda, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);

        add(toolbar, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
        add(statusBar, BorderLayout.SOUTH);

        cargarDatos();
    }

    private void cargarDatos() {
        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() throws Exception {
                String json = ApiClient.get("/movimientos");
                movimientos = ApiClient.getGson().fromJson(json, new TypeToken<List<MovimientoDTO>>(){}.getType());
                return null;
            }
            @Override protected void done() {
                try { get(); rellenarTabla(movimientos); }
                catch (Exception ex) {
                    JOptionPane.showMessageDialog(MovimientosPanel.this,
                            "Error al cargar movimientos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }

    private void rellenarTabla(List<MovimientoDTO> lista) {
        modelo.setRowCount(0);
        if (lista == null) return;
        for (MovimientoDTO m : lista) {
            modelo.addRow(new Object[]{
                m.iD_Movimiento,
                m.fechaHora != null ? m.fechaHora.replace("T", " ").substring(0, Math.min(m.fechaHora.length(), 19)) : "—",
                m.tipoMovimiento,
                m.cantidadMovida,
                m.nombreProducto,
                m.codigoLote != null ? m.codigoLote : "—",
                m.nombreUsuario,
                m.observaciones != null ? m.observaciones : "—"
            });
        }
    }

    private void filtrar(String texto) {
        if (texto == null || texto.trim().isEmpty()) { rellenarTabla(movimientos); return; }
        String q = texto.toLowerCase();
        List<MovimientoDTO> f = movimientos.stream()
                .filter(m -> (m.nombreProducto != null && m.nombreProducto.toLowerCase().contains(q))
                          || m.tipoMovimiento.toLowerCase().contains(q)
                          || (m.nombreUsuario != null && m.nombreUsuario.toLowerCase().contains(q)))
                .toList();
        rellenarTabla(f);
    }

    private JLabel crearLeyenda(String texto, Color color) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lbl.setForeground(color);
        return lbl;
    }
}

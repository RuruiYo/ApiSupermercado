package administrador.ui.panels;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import administrador.models.UsuarioDTO;
import administrador.services.ApiClient;
import administrador.ui.UIUtils;
import administrador.ui.dialogs.UsuarioDialog;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UsuariosPanel extends JPanel {

    private final DefaultTableModel modelo;
    private final JTable tabla;
    private List<UsuarioDTO> usuarios = new ArrayList<>();
    private JsonArray cajasData = new JsonArray();

    public UsuariosPanel() {
        setLayout(new BorderLayout());
        setBackground(UIUtils.BG_PANEL);

        // ── TOOLBAR ───────────────────────────────────────────────────────────
        JPanel toolbar = new JPanel(new BorderLayout());
        toolbar.setBackground(UIUtils.BG_PANEL);
        toolbar.setBorder(new EmptyBorder(18, 24, 12, 24));

        JLabel titulo = new JLabel("Usuarios del Sistema");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(UIUtils.TEXT_PRIMARY);

        JPanel derecha = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        derecha.setOpaque(false);

        JButton btnNuevo   = UIUtils.crearBoton("+ Nuevo Usuario", UIUtils.GREEN, UIUtils.BG_DARK);
        JButton btnActivar = UIUtils.crearBoton("✔ Activar", new Color(34, 197, 94), Color.WHITE);
        JButton btnDesact  = UIUtils.crearBoton("✖ Desactivar", UIUtils.RED, Color.WHITE);
        JButton btnCaja    = UIUtils.crearBoton("Asignar Caja", UIUtils.BLUE, Color.WHITE);
        JButton btnRefresh = UIUtils.crearBoton("↺", UIUtils.BORDER_COLOR, UIUtils.TEXT_LABEL);

        btnNuevo.addActionListener(e   -> abrirDialogo());
        btnActivar.addActionListener(e -> cambiarEstado(true));
        btnDesact.addActionListener(e  -> cambiarEstado(false));
        btnCaja.addActionListener(e    -> asignarCaja());
        btnRefresh.addActionListener(e -> cargarDatos());

        derecha.add(btnNuevo);
        derecha.add(btnActivar);
        derecha.add(btnDesact);
        derecha.add(btnCaja);
        derecha.add(btnRefresh);
        toolbar.add(titulo, BorderLayout.WEST);
        toolbar.add(derecha, BorderLayout.EAST);

        // ── TABLA ─────────────────────────────────────────────────────────────
        String[] cols = {"ID", "Nombre Completo", "Correo", "Rol", "Caja Asignada", "Estado"};
        modelo = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        tabla = new JTable(modelo);
        UIUtils.estilizarTabla(tabla);
        tabla.getColumnModel().getColumn(0).setMaxWidth(50);
        tabla.getColumnModel().getColumn(2).setPreferredWidth(200);
        tabla.getColumnModel().getColumn(3).setMaxWidth(110);
        tabla.getColumnModel().getColumn(4).setPreferredWidth(120);
        tabla.getColumnModel().getColumn(5).setMaxWidth(90);

        // Renderer: Estado
        tabla.getColumnModel().getColumn(5).setCellRenderer(UIUtils.estadoRenderer());

        // Renderer: Rol con colores por tipo
        tabla.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                String rol = v != null ? v.toString() : "";
                setHorizontalAlignment(CENTER);
                setFont(new Font("Segoe UI", Font.BOLD, 11));
                setBackground(sel ? UIUtils.BG_SELECTED
                        : (row % 2 == 0 ? UIUtils.BG_DARK : UIUtils.BG_ROW_ALT));
                switch (rol) {
                    case "Administrador": setForeground(UIUtils.ORANGE); break;
                    case "Bodeguero":     setForeground(UIUtils.YELLOW); break;
                    case "Cajero":        setForeground(UIUtils.BLUE);   break;
                    default:              setForeground(UIUtils.TEXT_MUTED); break;
                }
                return this;
            }
        });

        // Renderer: Caja Asignada
        tabla.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                String val = v != null ? v.toString() : "—";
                setBorder(new EmptyBorder(0, 12, 0, 12));
                setBackground(sel ? UIUtils.BG_SELECTED
                        : (row % 2 == 0 ? UIUtils.BG_DARK : UIUtils.BG_ROW_ALT));
                if (val.equals("—")) {
                    setText("—");
                    setForeground(UIUtils.TEXT_MUTED);
                } else if (val.equals("Sin caja")) {
                    setText("⚠ Sin caja");
                    setForeground(UIUtils.RED);
                } else {
                    setText("✔ " + val);
                    setForeground(UIUtils.GREEN);
                }
                return this;
            }
        });

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIUtils.BORDER_COLOR));
        scroll.getViewport().setBackground(UIUtils.BG_DARK);

        JPanel info = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 6));
        info.setBackground(new Color(18, 28, 40));
        info.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, UIUtils.BORDER_COLOR));
        JLabel lblInfo = new JLabel(
            "Selecciona un Cajero y pulsa 'Asignar Caja' para elegir en cuál caja trabajará.");
        lblInfo.setForeground(UIUtils.TEXT_MUTED);
        lblInfo.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        info.add(lblInfo);

        JPanel center = new JPanel(new BorderLayout());
        center.add(info, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);

        add(toolbar, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

        cargarDatos();
    }

    // ── CARGAR DATOS ─────────────────────────────────────────────────────────
    private void cargarDatos() {
        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() throws Exception {
                String jsonU = ApiClient.get("/usuarios");
                String jsonC = ApiClient.get("/cajas");
                System.out.println("[DEBUG] JSON cajas: " + jsonC);
                usuarios  = ApiClient.getGson().fromJson(
                    jsonU, new TypeToken<List<UsuarioDTO>>(){}.getType());
                cajasData = new JsonParser().parse(jsonC).getAsJsonArray();
                System.out.println("[DEBUG] cajasData.size(): " + cajasData.size());
                return null;
            }
            @Override protected void done() {
                try { get(); rellenarTabla(); }
                catch (Exception ex) {
                    JOptionPane.showMessageDialog(UsuariosPanel.this,
                        "Error al cargar datos: " + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }

    private void rellenarTabla() {
        modelo.setRowCount(0);
        if (usuarios == null) return;
        for (UsuarioDTO u : usuarios) {
            String cajaAsignada = "—";
            if ("Cajero".equals(u.nombreRol)) {
                cajaAsignada = "Sin caja";
                for (int j = 0; j < cajasData.size(); j++) {
                    JsonObject c = cajasData.get(j).getAsJsonObject();
                    if (tieneValor(c, "iD_Cajero") && c.get("iD_Cajero").getAsInt() == u.iD_Usuario
                            && c.get("estadoActiva").getAsBoolean()) {
                        cajaAsignada = c.get("nombreCaja").getAsString();
                        break;
                    }
                }
            }
            modelo.addRow(new Object[]{
                u.iD_Usuario, u.nombreCompleto, u.correo_Usuario,
                u.nombreRol, cajaAsignada, u.estadoActivo ? "Activo" : "Inactivo"
            });
        }
    }

    // ── CAMBIAR ESTADO ────────────────────────────────────────────────────────
    private void cambiarEstado(boolean activar) {
        int row = tabla.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un usuario.",
                "Aviso", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int    id     = (int)    modelo.getValueAt(row, 0);
        String nombre = (String) modelo.getValueAt(row, 1);

        int confirm = JOptionPane.showConfirmDialog(this,
            "¿Desea " + (activar ? "activar" : "desactivar") + " al usuario:\n" + nombre + "?",
            "Confirmar acción", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        new SwingWorker<Void, Void>() {
            String error = null;
            @Override protected Void doInBackground() throws Exception {
                Map<String, Boolean> body = new HashMap<>();
                body.put("estadoActivo", activar);
                ApiClient.ApiResponse resp = ApiClient.patch("/usuarios/" + id + "/estado", body);
                if (!resp.isOk()) error = resp.getMensajeError();
                return null;
            }
            @Override protected void done() {
                if (error != null)
                    JOptionPane.showMessageDialog(UsuariosPanel.this, error, "Error", JOptionPane.ERROR_MESSAGE);
                else
                    cargarDatos();
            }
        }.execute();
    }

    // ── ASIGNAR CAJA ──────────────────────────────────────────────────────────
    private void asignarCaja() {
        int row = tabla.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un usuario.",
                "Aviso", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String rol = (String) modelo.getValueAt(row, 3);
        if (!"Cajero".equals(rol)) {
            JOptionPane.showMessageDialog(this,
                "Solo se puede asignar una caja a usuarios con rol Cajero.",
                "Rol incorrecto", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int    idCajero     = (int)    modelo.getValueAt(row, 0);
        String nombreCajero = (String) modelo.getValueAt(row, 1);
        String cajaActual   = (String) modelo.getValueAt(row, 4);

        // Construir lista de cajas disponibles para el combobox
        // Incluir la caja actual del cajero (aunque no esté "disponible") + las libres
        List<JsonObject> cajasOpciones = new ArrayList<>();
        for (int j = 0; j < cajasData.size(); j++) {
            JsonObject c = cajasData.get(j).getAsJsonObject();
            if (!c.get("estadoActiva").getAsBoolean()) continue;

            // FIXED: Usar el campo 'disponible' que el API ya calcula correctamente
            boolean esLibre = c.has("disponible") && c.get("disponible").getAsBoolean();
            boolean esSuCaja = tieneValor(c, "iD_Cajero")
                               && c.get("iD_Cajero").getAsInt() == idCajero;
            System.out.println("[DEBUG] Caja: " + c.get("nombreCaja")
                + " | disponible: " + esLibre
                + " | esSuCaja: " + esSuCaja);
            if (esLibre || esSuCaja) cajasOpciones.add(c);
        }

        System.out.println("[DEBUG] Total opciones encontradas: " + cajasOpciones.size());

        if (cajasOpciones.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "No hay cajas disponibles en este momento.\n" +
                "Todas las cajas están ocupadas por otros cajeros.",
                "Sin cajas disponibles", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // ── Diálogo con combobox ──────────────────────────────────────────────
        JDialog dlg = new JDialog(SwingUtilities.getWindowAncestor(this),
            "Asignar Caja — " + nombreCajero, Dialog.ModalityType.APPLICATION_MODAL);
        dlg.setSize(500, 450);
        dlg.setLocationRelativeTo(this);
        dlg.setResizable(false);
        dlg.getContentPane().setBackground(UIUtils.BG_CARD);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UIUtils.BG_CARD);
        panel.setBorder(new EmptyBorder(24, 28, 24, 28));

        JLabel lblTitulo = new JLabel("Asignar Caja");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTitulo.setForeground(UIUtils.TEXT_PRIMARY);
        lblTitulo.setAlignmentX(LEFT_ALIGNMENT);

        JLabel lblCajero = new JLabel("Cajero: " + nombreCajero);
        lblCajero.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblCajero.setForeground(UIUtils.TEXT_MUTED);
        lblCajero.setAlignmentX(LEFT_ALIGNMENT);

        JLabel lblActual = new JLabel("Asignación actual: " +
            (cajaActual.equals("Sin caja") ? "ninguna" : cajaActual));
        lblActual.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblActual.setForeground(cajaActual.equals("Sin caja") ? UIUtils.RED : UIUtils.GREEN);
        lblActual.setAlignmentX(LEFT_ALIGNMENT);

        panel.add(lblTitulo);
        panel.add(Box.createVerticalStrut(4));
        panel.add(lblCajero);
        panel.add(Box.createVerticalStrut(3));
        panel.add(lblActual);
        panel.add(Box.createVerticalStrut(20));

        // ComboBox con las cajas disponibles
        JLabel lblCaja = UIUtils.crearLabel("Seleccionar Caja *");
        lblCaja.setAlignmentX(LEFT_ALIGNMENT);

        JComboBox<String> cmbCajas = new JComboBox<>();
        cmbCajas.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbCajas.setBackground(UIUtils.BG_INPUT);
        cmbCajas.setForeground(UIUtils.TEXT_PRIMARY);
        cmbCajas.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        cmbCajas.setAlignmentX(LEFT_ALIGNMENT);

        for (JsonObject c : cajasOpciones) {
            String nombre   = c.get("nombreCaja").getAsString();
            boolean esSuya  = tieneValor(c, "iD_Cajero")
                               && c.get("iD_Cajero").getAsInt() == idCajero;
            cmbCajas.addItem(nombre + (esSuya ? " (actual)" : " — libre"));
        }

        // Preseleccionar su caja actual si tiene
        for (int i = 0; i < cajasOpciones.size(); i++) {
            JsonObject c = cajasOpciones.get(i);
            if (tieneValor(c, "iD_Cajero")
                    && c.get("iD_Cajero").getAsInt() == idCajero) {
                cmbCajas.setSelectedIndex(i);
                break;
            }
        }

        // Saldo inicial
        JLabel lblSaldo = UIUtils.crearLabel("Saldo Inicial ($)");
        lblSaldo.setAlignmentX(LEFT_ALIGNMENT);
        JTextField txtSaldo = UIUtils.crearTextField("");
        txtSaldo.setText("50.00");
        txtSaldo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        txtSaldo.setAlignmentX(LEFT_ALIGNMENT);

        panel.add(lblCaja);
        panel.add(Box.createVerticalStrut(5));
        panel.add(cmbCajas);
        panel.add(Box.createVerticalStrut(12));
        panel.add(lblSaldo);
        panel.add(Box.createVerticalStrut(5));
        panel.add(txtSaldo);
        panel.add(Box.createVerticalStrut(20));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setOpaque(false);
        btnRow.setAlignmentX(LEFT_ALIGNMENT);

        JButton btnCancelar = UIUtils.crearBoton("Cancelar", UIUtils.BORDER_COLOR, UIUtils.TEXT_LABEL);
        JButton btnGuardar  = UIUtils.crearBoton("Asignar", UIUtils.GREEN, UIUtils.BG_DARK);
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 13));

        btnCancelar.addActionListener(e -> dlg.dispose());

        final List<JsonObject> opcionesFinal = cajasOpciones;
        btnGuardar.addActionListener(e -> {
            int idx = cmbCajas.getSelectedIndex();
            if (idx < 0) return;

            double saldo;
            try {
                saldo = Double.parseDouble(txtSaldo.getText().trim().replace(",", "."));
                if (saldo < 0) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dlg,
                    "El saldo inicial debe ser un número mayor o igual a 0.",
                    "Validación", JOptionPane.WARNING_MESSAGE);
                return;
            }

            JsonObject cajaSeleccionada = opcionesFinal.get(idx);
            int idCaja = cajaSeleccionada.get("iD_Caja").getAsInt();
            String nombreCaja = cajaSeleccionada.get("nombreCaja").getAsString();
            final double saldoFinal = saldo;

            new SwingWorker<Void, Void>() {
                String error = null;
                @Override protected Void doInBackground() throws Exception {
                    // Si el cajero ya tenía otra caja → desasignar primero
                    int idCajaAnterior = buscarIdCajaActiva(idCajero);
                    if (idCajaAnterior > 0 && idCajaAnterior != idCaja) {
                        Map<String, Object> desasig = new HashMap<>();
                        desasig.put("iD_Usuario_Cajero", null);
                        desasig.put("saldoInicial", 0);
                        ApiClient.patch("/cajas/" + idCajaAnterior + "/asignar", desasig);
                    }

                    // Asignar cajero a la caja seleccionada
                    Map<String, Object> body = new HashMap<>();
                    body.put("iD_Usuario_Cajero", idCajero);
                    body.put("saldoInicial", saldoFinal);
                    ApiClient.ApiResponse resp =
                        ApiClient.patch("/cajas/" + idCaja + "/asignar", body);
                    if (!resp.isOk()) error = resp.getMensajeError();
                    return null;
                }
                @Override protected void done() {
                    if (error != null) {
                        JOptionPane.showMessageDialog(dlg, error, "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        dlg.dispose();
                        JOptionPane.showMessageDialog(UsuariosPanel.this,
                            nombreCajero + " asignado a " + nombreCaja + " correctamente.",
                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        cargarDatos();
                    }
                }
            }.execute();
        });

        btnRow.add(btnCancelar);
        btnRow.add(btnGuardar);
        panel.add(btnRow);

        dlg.add(panel);
        dlg.setVisible(true);
    }

    /** Devuelve true si el campo existe, no es null Java y no es JsonNull */
    private static boolean tieneValor(JsonObject obj, String campo) {
        JsonElement el = obj.get(campo);
        return el != null && !el.isJsonNull();
    }

    private int buscarIdCajaActiva(int idCajero) {
        for (int j = 0; j < cajasData.size(); j++) {
            JsonObject c = cajasData.get(j).getAsJsonObject();
            if (tieneValor(c, "iD_Cajero")
                    && c.get("iD_Cajero").getAsInt() == idCajero
                    && c.get("estadoActiva").getAsBoolean()) {
                return c.get("iD_Caja").getAsInt();
            }
        }
        return -1;
    }

    private void abrirDialogo() {
        UsuarioDialog dlg = new UsuarioDialog(SwingUtilities.getWindowAncestor(this));
        dlg.setVisible(true);
        if (dlg.isSaved()) cargarDatos();
    }
}
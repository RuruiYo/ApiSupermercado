package administrador.ui.panels;

import administrador.models.ProveedorDTO;
import administrador.services.ApiClient;
import administrador.ui.UIUtils;
import administrador.ui.dialogs.ProveedorDialog;
import com.google.gson.reflect.TypeToken;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProveedoresPanel extends JPanel {

    private final DefaultTableModel modelo;
    private final JTable tabla;
    private List proveedores = new ArrayList();

    public ProveedoresPanel() {
        setLayout(new BorderLayout());
        setBackground(UIUtils.BG_PANEL);

        JPanel toolbar = new JPanel(new BorderLayout());
        toolbar.setBackground(UIUtils.BG_PANEL);
        toolbar.setBorder(new EmptyBorder(18, 24, 12, 24));

        JLabel titulo = new JLabel("Proveedores");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(UIUtils.TEXT_PRIMARY);

        JPanel derecha = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        derecha.setOpaque(false);

        JButton btnNuevo   = UIUtils.crearBoton("+ Nuevo Proveedor", UIUtils.GREEN, UIUtils.BG_DARK);
        JButton btnActivar = UIUtils.crearBoton("Activar", new Color(34, 197, 94), Color.WHITE);
        JButton btnDesact  = UIUtils.crearBoton("Desactivar", UIUtils.RED, Color.WHITE);
        JButton btnRefresh = UIUtils.crearBoton("Actualizar", UIUtils.BORDER_COLOR, UIUtils.TEXT_LABEL);

        btnNuevo.addActionListener(e -> abrirDialogo());
        btnActivar.addActionListener(e -> cambiarEstado(true));
        btnDesact.addActionListener(e -> cambiarEstado(false));
        btnRefresh.addActionListener(e -> cargarDatos());

        derecha.add(btnNuevo);
        derecha.add(btnActivar);
        derecha.add(btnDesact);
        derecha.add(btnRefresh);
        toolbar.add(titulo, BorderLayout.WEST);
        toolbar.add(derecha, BorderLayout.EAST);

        String[] cols = {"ID", "Empresa", "Contacto", "Teléfono", "Estado"};
        modelo = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        tabla = new JTable(modelo);
        UIUtils.estilizarTabla(tabla);
        tabla.getColumnModel().getColumn(4).setCellRenderer(UIUtils.estadoRenderer());
        tabla.getColumnModel().getColumn(0).setMaxWidth(50);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(200);
        tabla.getColumnModel().getColumn(4).setMaxWidth(120);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIUtils.BORDER_COLOR));
        scroll.getViewport().setBackground(UIUtils.BG_DARK);

        add(toolbar, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        cargarDatos();
    }

    private void cargarDatos() {
        new SwingWorker() {
            protected Object doInBackground() throws Exception {
                String json = ApiClient.get("/proveedores");
                proveedores = ApiClient.getGson().fromJson(
                    json, new TypeToken<List<ProveedorDTO>>(){}.getType());
                return null;
            }
            protected void done() {
                try {
                    get();
                    rellenarTabla();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(ProveedoresPanel.this,
                        "Error al cargar proveedores:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }

    private void rellenarTabla() {
        modelo.setRowCount(0);
        if (proveedores == null) return;
        for (Object o : proveedores) {
            ProveedorDTO p = (ProveedorDTO) o;
            modelo.addRow(new Object[]{
                p.iD_Proveedor,
                p.nombreEmpresa,
                p.contactoAsignado != null ? p.contactoAsignado : "—",
                p.telefono != null ? p.telefono : "—",
                p.estadoActivo ? "Activo" : "Inactivo"
            });
        }
    }

    private void cambiarEstado(boolean activar) {
        int row = tabla.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un proveedor.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int id = (Integer) modelo.getValueAt(row, 0);
        String nombre = (String) modelo.getValueAt(row, 1);
        String accion = activar ? "activar" : "desactivar";

        int confirm = JOptionPane.showConfirmDialog(this,
            "¿Desea " + accion + " al proveedor:\n" + nombre + "?",
            "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        new SwingWorker() {
            String error = null;
            protected Object doInBackground() throws Exception {
                Map body = new HashMap();
                body.put("estadoActivo", activar);
                ApiClient.ApiResponse resp = ApiClient.patch("/proveedores/" + id + "/estado", body);
                if (!resp.isOk()) error = resp.getMensajeError();
                return null;
            }
            protected void done() {
                if (error != null) {
                    JOptionPane.showMessageDialog(ProveedoresPanel.this, error, "Error", JOptionPane.ERROR_MESSAGE);
                } else { cargarDatos(); }
            }
        }.execute();
    }

    private void abrirDialogo() {
        ProveedorDialog dlg = new ProveedorDialog(SwingUtilities.getWindowAncestor(this));
        dlg.setVisible(true);
        if (dlg.isSaved()) cargarDatos();
    }
}

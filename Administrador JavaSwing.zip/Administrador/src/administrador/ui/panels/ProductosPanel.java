package administrador.ui.panels;

import administrador.models.CategoriaDTO;
import administrador.models.ProductoDTO;
import administrador.models.UbicacionDTO;
import administrador.services.ApiClient;
import administrador.ui.UIUtils;
import administrador.ui.dialogs.ProductoDialog;
import com.google.gson.reflect.TypeToken;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

public class ProductosPanel extends JPanel {

    private final DefaultTableModel modelo;
    private final JTable tabla;
    private final JTextField txtBuscar;
    private List productos  = new ArrayList();
    private List categorias = new ArrayList();
    private List ubicaciones= new ArrayList();

    public ProductosPanel() {
        setLayout(new BorderLayout());
        setBackground(UIUtils.BG_PANEL);

        // ── TOOLBAR ───────────────────────────────────────────────────────────
        JPanel toolbar = new JPanel(new BorderLayout());
        toolbar.setBackground(UIUtils.BG_PANEL);
        toolbar.setBorder(new EmptyBorder(18, 24, 12, 24));

        JLabel titulo = new JLabel("Productos");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(UIUtils.TEXT_PRIMARY);

        JPanel derecha = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        derecha.setOpaque(false);

        // Buscador con placeholder
        txtBuscar = UIUtils.crearTextField("");
        txtBuscar.setPreferredSize(new Dimension(240, 34));
        txtBuscar.setToolTipText("Buscar por nombre, SKU, categoría o ubicación");

        // Placeholder visual
        txtBuscar.setText("Buscar nombre, SKU o ubicación...");
        txtBuscar.setForeground(UIUtils.TEXT_MUTED);
        txtBuscar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (txtBuscar.getText().equals("Buscar nombre, SKU o ubicación...")) {
                    txtBuscar.setText("");
                    txtBuscar.setForeground(UIUtils.TEXT_PRIMARY);
                }
            }
            public void focusLost(java.awt.event.FocusEvent e) {
                if (txtBuscar.getText().isEmpty()) {
                    txtBuscar.setText("Buscar nombre, SKU o ubicación...");
                    txtBuscar.setForeground(UIUtils.TEXT_MUTED);
                }
            }
        });
        txtBuscar.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                String texto = txtBuscar.getText();
                if (texto.equals("Buscar nombre, SKU o ubicación...")) return;
                filtrar(texto);
            }
        });

        JButton btnNuevo   = UIUtils.crearBoton("+ Nuevo", UIUtils.GREEN, UIUtils.BG_DARK);
        JButton btnEditar  = UIUtils.crearBoton("Editar", UIUtils.BLUE, Color.WHITE);
        JButton btnRefresh = UIUtils.crearBoton("Actualizar", UIUtils.BORDER_COLOR, UIUtils.TEXT_LABEL);

        btnNuevo.addActionListener(e -> abrirDialogo(null));
        btnEditar.addActionListener(e -> editarSeleccionado());
        btnRefresh.addActionListener(e -> cargarDatos());

        derecha.add(txtBuscar);
        derecha.add(btnNuevo);
        derecha.add(btnEditar);
        derecha.add(btnRefresh);

        toolbar.add(titulo, BorderLayout.WEST);
        toolbar.add(derecha, BorderLayout.EAST);

        // ── HINT bajo el buscador ─────────────────────────────────────────────
        JPanel hint = new JPanel(new FlowLayout(FlowLayout.RIGHT, 24, 2));
        hint.setBackground(UIUtils.BG_PANEL);
        JLabel lblHint = new JLabel("Tip: escribe 'Pasillo A' o 'Bodega Fría' para filtrar por ubicación");
        lblHint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblHint.setForeground(UIUtils.TEXT_MUTED);
        hint.add(lblHint);

        JPanel north = new JPanel(new BorderLayout());
        north.setBackground(UIUtils.BG_PANEL);
        north.add(toolbar, BorderLayout.CENTER);
        north.add(hint, BorderLayout.SOUTH);

        // ── TABLA ─────────────────────────────────────────────────────────────
        String[] cols = {"ID", "SKU", "Nombre", "Categoría", "Ubicación", "Precio", "Bodega", "Estante", "Reservado"};
        modelo = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
            public Class getColumnClass(int c) {
                if (c == 0 || c == 6 || c == 7 || c == 8) return Integer.class;
                if (c == 5) return Double.class;
                return String.class;
            }
        };

        tabla = new JTable(modelo);
        UIUtils.estilizarTabla(tabla);
        tabla.getColumnModel().getColumn(0).setMaxWidth(50);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(90);
        tabla.getColumnModel().getColumn(2).setPreferredWidth(200);
        tabla.getColumnModel().getColumn(3).setPreferredWidth(100);
        tabla.getColumnModel().getColumn(4).setPreferredWidth(130);
        tabla.getColumnModel().getColumn(5).setPreferredWidth(80);
        tabla.getColumnModel().getColumn(6).setPreferredWidth(65);
        tabla.getColumnModel().getColumn(7).setPreferredWidth(65);
        tabla.getColumnModel().getColumn(8).setPreferredWidth(75);

        // Doble clic para editar
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) editarSeleccionado();
            }
        });

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIUtils.BORDER_COLOR));
        scroll.getViewport().setBackground(UIUtils.BG_DARK);

        // ── STATUS BAR ────────────────────────────────────────────────────────
        JPanel statusBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 4));
        statusBar.setBackground(UIUtils.BG_CARD);
        statusBar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIUtils.BORDER_COLOR));
        JLabel lblTotal = new JLabel("Total: 0 productos");
        lblTotal.setForeground(UIUtils.TEXT_MUTED);
        lblTotal.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        statusBar.add(lblTotal);
        modelo.addTableModelListener(e2 ->
            lblTotal.setText("Total: " + modelo.getRowCount() + " productos"));

        add(north, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(statusBar, BorderLayout.SOUTH);

        cargarDatos();
    }

    private void cargarDatos() {
        new SwingWorker() {
            String error = null;
            protected Object doInBackground() throws Exception {
                try {
                    String jsonP = ApiClient.get("/productos");
                    String jsonC = ApiClient.get("/categorias");
                    String jsonU = ApiClient.get("/ubicaciones");
                    productos   = ApiClient.getGson().fromJson(jsonP, new TypeToken<List<ProductoDTO>>(){}.getType());
                    categorias  = ApiClient.getGson().fromJson(jsonC, new TypeToken<List<CategoriaDTO>>(){}.getType());
                    ubicaciones = ApiClient.getGson().fromJson(jsonU, new TypeToken<List<UbicacionDTO>>(){}.getType());
                } catch (Exception ex) {
                    error = ex.getMessage();
                }
                return null;
            }
            protected void done() {
                if (error != null) {
                    JOptionPane.showMessageDialog(ProductosPanel.this,
                        "Error al cargar datos:\n" + error, "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                rellenarTabla(productos);
            }
        }.execute();
    }

    private void rellenarTabla(List lista) {
        modelo.setRowCount(0);
        if (lista == null) return;
        for (Object o : lista) {
            ProductoDTO p = (ProductoDTO) o;
            modelo.addRow(new Object[]{
                p.iD_Producto,
                p.sKU_CodigoInterno,
                p.nombreProducto,
                p.nombreCategoria  != null ? p.nombreCategoria  : "—",
                p.nombreUbicacion  != null ? p.nombreUbicacion  : "—",
                p.precioVenta,
                p.stock_Bodega_Total,
                p.stock_Estante_Total,
                p.stock_Reservado_Total
            });
        }
    }

    /**
     * Filtra por nombre de producto, SKU, categoría O ubicación.
     * Escribir "Pasillo A" muestra solo los productos de ese pasillo.
     */
    private void filtrar(String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            rellenarTabla(productos);
            return;
        }
        String q = texto.trim().toLowerCase();
        List filtrados = new ArrayList();
        for (Object o : productos) {
            ProductoDTO p = (ProductoDTO) o;
            boolean coincide =
                p.nombreProducto.toLowerCase().contains(q)
                || (p.sKU_CodigoInterno != null && p.sKU_CodigoInterno.toLowerCase().contains(q))
                || (p.nombreCategoria != null && p.nombreCategoria.toLowerCase().contains(q))
                || (p.nombreUbicacion != null && p.nombreUbicacion.toLowerCase().contains(q));
            if (coincide) filtrados.add(p);
        }
        rellenarTabla(filtrados);
    }

    private void editarSeleccionado() {
        int row = tabla.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this,
                "Seleccione un producto de la tabla.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int id = (Integer) modelo.getValueAt(row, 0);
        ProductoDTO p = null;
        for (Object o : productos) {
            ProductoDTO pd = (ProductoDTO) o;
            if (pd.iD_Producto == id) { p = pd; break; }
        }
        abrirDialogo(p);
    }

    private void abrirDialogo(ProductoDTO p) {
        ProductoDialog dlg = new ProductoDialog(
            SwingUtilities.getWindowAncestor(this), p, categorias, ubicaciones);
        dlg.setVisible(true);
        if (dlg.isSaved()) cargarDatos();
    }
}
package administrador.ui.panels;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import administrador.services.ApiClient;
import administrador.ui.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

public class LoginPanel extends JPanel {

    private final JTextField txtCorreo;
    private final JPasswordField txtPassword;
    private final JButton btnLogin;
    private final JLabel lblError;
    private final Consumer<String> onLoginSuccess;

    public LoginPanel(Consumer<String> onLoginSuccess) {
        this.onLoginSuccess = onLoginSuccess;
        setLayout(new GridBagLayout());
        setBackground(UIUtils.BG_PANEL);

        // ── Tarjeta central ───────────────────────────────────────────────────
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(UIUtils.BG_CARD);
        card.setBorder(new EmptyBorder(45, 50, 45, 50));
        card.setPreferredSize(new Dimension(420, 480));

        // Logo / Título
        JLabel icono = new JLabel("🏪");
        icono.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 42));
        icono.setAlignmentX(CENTER_ALIGNMENT);

        JLabel titulo = new JLabel("Supermercado");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titulo.setForeground(UIUtils.GREEN);
        titulo.setAlignmentX(CENTER_ALIGNMENT);

        JLabel subtitulo = new JLabel("Panel de Administración");
        subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitulo.setForeground(UIUtils.TEXT_MUTED);
        subtitulo.setAlignmentX(CENTER_ALIGNMENT);

        // Separador
        JSeparator sep = new JSeparator();
        sep.setForeground(UIUtils.BORDER_COLOR);
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));

        // Correo
        JLabel lblCorreo = UIUtils.crearLabel("Correo electrónico");
        lblCorreo.setAlignmentX(LEFT_ALIGNMENT);
        txtCorreo = UIUtils.crearTextField("admin@super.com");
       
        txtCorreo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        txtCorreo.setAlignmentX(LEFT_ALIGNMENT);

        // Password
        JLabel lblPass = UIUtils.crearLabel("Contraseña");
        lblPass.setAlignmentX(LEFT_ALIGNMENT);
        txtPassword = UIUtils.crearPasswordField();
        
        txtPassword.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        txtPassword.setAlignmentX(LEFT_ALIGNMENT);

        // Error
        lblError = new JLabel(" ");
        lblError.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblError.setForeground(UIUtils.RED);
        lblError.setAlignmentX(CENTER_ALIGNMENT);

        // Botón login
        btnLogin = UIUtils.crearBoton("Iniciar Sesión", UIUtils.GREEN, UIUtils.BG_DARK);
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnLogin.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        btnLogin.setAlignmentX(LEFT_ALIGNMENT);
        btnLogin.addActionListener(e -> doLogin());

        txtPassword.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) doLogin();
            }
        });

        card.add(icono);
        card.add(Box.createVerticalStrut(8));
        card.add(titulo);
        card.add(Box.createVerticalStrut(4));
        card.add(subtitulo);
        card.add(Box.createVerticalStrut(20));
        card.add(sep);
        card.add(Box.createVerticalStrut(24));
        card.add(lblCorreo);
        card.add(Box.createVerticalStrut(6));
        card.add(txtCorreo);
        card.add(Box.createVerticalStrut(16));
        card.add(lblPass);
        card.add(Box.createVerticalStrut(6));
        card.add(txtPassword);
        card.add(Box.createVerticalStrut(12));
        card.add(lblError);
        card.add(Box.createVerticalStrut(8));
        card.add(btnLogin);

        add(card);
    }

    private void doLogin() {
        String correo = txtCorreo.getText().trim();
        String pass = new String(txtPassword.getPassword());

        if (correo.isEmpty() || pass.isEmpty()) {
            lblError.setText("Complete todos los campos.");
            return;
        }

        btnLogin.setEnabled(false);
        btnLogin.setText("Verificando...");
        lblError.setText(" ");

        new SwingWorker<Void, Void>() {
            String errorMsg = null;
            String nombreAdmin = null;

            @Override protected Void doInBackground() {
                try {
                    Map<String, String> body = new HashMap<>();
                    body.put("correo_Usuario", correo);
                    body.put("contrasena", pass);

                    ApiClient.ApiResponse resp = ApiClient.postPublic("/auth/login", body);

                    if (resp.isOk()) {
                        // Uso compatible con Gson antiguo
                        JsonParser parser = new JsonParser();
                        JsonObject json = parser.parse(resp.body).getAsJsonObject();

                        String rol = json.get("rol").getAsString();
                        if (!"Administrador".equals(rol)) {
                            errorMsg = "Acceso denegado. Solo administradores pueden ingresar.";
                            return null;
                        }
                        ApiClient.setToken(json.get("token").getAsString());
                        nombreAdmin = json.get("nombreCompleto").getAsString();
                    } else {
                        errorMsg = ApiClient.getMensaje(resp.body);
                    }
                } catch (Exception ex) {
                    errorMsg = "No se pudo conectar a la API. ¿Está corriendo en puerto 5153?";
                }
                return null;
            }

            @Override protected void done() {
                btnLogin.setEnabled(true);
                btnLogin.setText("Iniciar Sesión");
                if (errorMsg != null) {
                    lblError.setText(errorMsg);
                } else {
                    onLoginSuccess.accept(nombreAdmin);
                }
            }
        }.execute();
    }
}

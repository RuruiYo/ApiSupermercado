package administrador.ui.panels;

import administrador.services.ApiClient;
import administrador.ui.UIUtils;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class UbicacionesPanel extends JPanel {

    private final DefaultTableModel modelo;
    private final JTable tabla;

    public UbicacionesPanel() {
        setLayout(new BorderLayout());
        setBackground(UIUtils.BG_PANEL);

        JPanel toolbar = new JPanel(new BorderLayout());
        toolbar.setBackground(UIUtils.BG_PANEL);
        toolbar.setBorder(new EmptyBorder(18, 24, 12, 24));

        JLabel titulo = new JLabel("Ubicaciones de Bodega");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(UIUtils.TEXT_PRIMARY);

        JPanel derecha = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        derecha.setOpaque(false);

        JButton btnNueva    = UIUtils.crearBoton("+ Nueva Ubicación", UIUtils.GREEN, UIUtils.BG_DARK);
        JButton btnEliminar = UIUtils.crearBoton("Eliminar", UIUtils.RED, Color.WHITE);
        JButton btnRefresh  = UIUtils.crearBoton("Actualizar", UIUtils.BORDER_COLOR, UIUtils.TEXT_LABEL);

        btnNueva.addActionListener(e -> agregarUbicacion());
        btnEliminar.addActionListener(e -> eliminarSeleccionada());
        btnRefresh.addActionListener(e -> cargarDatos());

        derecha.add(btnNueva);
        derecha.add(btnEliminar);
        derecha.add(btnRefresh);
        toolbar.add(titulo, BorderLayout.WEST);
        toolbar.add(derecha, BorderLayout.EAST);

        JPanel info = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 6));
        info.setBackground(new Color(20, 35, 25));
        info.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, UIUtils.BORDER_COLOR));
        JLabel lblInfo = new JLabel(
            "Las ubicaciones aparecen como combobox al crear/editar productos. " +
            "No puedes eliminar una ubicación con productos asignados.");
        lblInfo.setForeground(UIUtils.TEXT_MUTED);
        lblInfo.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        info.add(lblInfo);

        String[] cols = {"ID", "Nombre de Ubicación", "Productos Asignados"};
        modelo = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
            public Class getColumnClass(int c) {
                return (c == 0 || c == 2) ? Integer.class : String.class;
            }
        };

        tabla = new JTable(modelo);
        UIUtils.estilizarTabla(tabla);
        tabla.getColumnModel().getColumn(0).setMaxWidth(60);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(300);
        tabla.getColumnModel().getColumn(2).setMaxWidth(180);

        tabla.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                setHorizontalAlignment(CENTER);
                int total = v instanceof Integer ? (Integer) v : 0;
                setText(total > 0 ? total + " productos" : "Vacía");
                setForeground(total > 0 ? UIUtils.ORANGE : UIUtils.TEXT_MUTED);
                setBackground(sel ? UIUtils.BG_SELECTED : (row % 2 == 0 ? UIUtils.BG_DARK : UIUtils.BG_ROW_ALT));
                return this;
            }
        });

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIUtils.BORDER_COLOR));
        scroll.getViewport().setBackground(UIUtils.BG_DARK);

        JPanel center = new JPanel(new BorderLayout());
        center.add(info, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);

        add(toolbar, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

        cargarDatos();
    }

    private void cargarDatos() {
        new SwingWorker() {
            String json = null;
            String error = null;
            protected Object doInBackground() throws Exception {
                try { json = ApiClient.get("/ubicaciones"); }
                catch (Exception ex) { error = ex.getMessage(); }
                return null;
            }
            protected void done() {
                if (error != null) {
                    JOptionPane.showMessageDialog(UbicacionesPanel.this,
                        "Error al cargar ubicaciones:\n" + error, "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                modelo.setRowCount(0);
                try {
                    JsonArray arr = new JsonParser().parse(json).getAsJsonArray();
                    for (int i = 0; i < arr.size(); i++) {
                        JsonObject o = arr.get(i).getAsJsonObject();
                        modelo.addRow(new Object[]{
                            o.get("iD_Ubicacion").getAsInt(),
                            o.get("nombreUbicacion").getAsString(),
                            o.get("totalProductos").getAsInt()
                        });
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(UbicacionesPanel.this,
                        "Error al procesar respuesta:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }

    private void agregarUbicacion() {
        String nombre = JOptionPane.showInputDialog(this,
            "Nombre de la nueva ubicación:\n(Ej: Pasillo D, Bodega Congelados)",
            "Nueva Ubicación", JOptionPane.PLAIN_MESSAGE);
        if (nombre == null || nombre.trim().isEmpty()) return;

        final Map body = new HashMap();
        body.put("nombreUbicacion", nombre.trim());

        new SwingWorker() {
            String error = null;
            protected Object doInBackground() throws Exception {
                ApiClient.ApiResponse resp = ApiClient.post("/ubicaciones", body);
                if (!resp.isOk()) error = resp.getMensajeError();
                return null;
            }
            protected void done() {
                if (error != null) {
                    JOptionPane.showMessageDialog(UbicacionesPanel.this, error, "Error", JOptionPane.ERROR_MESSAGE);
                } else { cargarDatos(); }
            }
        }.execute();
    }

    private void eliminarSeleccionada() {
        int row = tabla.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una ubicación de la tabla.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int id = (Integer) modelo.getValueAt(row, 0);
        String nombre = (String) modelo.getValueAt(row, 1);
        int total = (Integer) modelo.getValueAt(row, 2);

        if (total > 0) {
            JOptionPane.showMessageDialog(this,
                "No se puede eliminar '" + nombre + "'.\n" +
                "Tiene " + total + " producto(s) asignado(s).\n" +
                "Reasigne los productos a otra ubicación primero.",
                "No permitido", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "¿Eliminar la ubicación '" + nombre + "'?",
            "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        new SwingWorker() {
            String error = null;
            protected Object doInBackground() throws Exception {
                ApiClient.ApiResponse resp = ApiClient.delete("/ubicaciones/" + id);
                if (!resp.isOk()) error = resp.getMensajeError();
                return null;
            }
            protected void done() {
                if (error != null) {
                    JOptionPane.showMessageDialog(UbicacionesPanel.this, error, "Error al eliminar", JOptionPane.ERROR_MESSAGE);
                } else { cargarDatos(); }
            }
        }.execute();
    }
}

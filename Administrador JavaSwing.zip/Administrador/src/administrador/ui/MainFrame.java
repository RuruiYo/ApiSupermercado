package administrador.ui;

import administrador.services.ApiClient;
import administrador.ui.panels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class MainFrame extends JFrame {

    private final JPanel contentArea;
    private final CardLayout cardLayout;
    private JButton btnActivo = null;

    private static final String P_PRODUCTOS   = "PRODUCTOS";
    private static final String P_USUARIOS    = "USUARIOS";
    private static final String P_PROVEEDORES = "PROVEEDORES";
    private static final String P_MOVIMIENTOS = "MOVIMIENTOS";

    public MainFrame(String adminName) {
        setTitle("Panel de Administración — Supermercado");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1200, 720);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);
        getContentPane().setBackground(UIUtils.BG_PANEL);
        setLayout(new BorderLayout());

        // ── SIDEBAR ───────────────────────────────────────────────────────────
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(UIUtils.BG_CARD);
        sidebar.setPreferredSize(new Dimension(220, 0));
        sidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, UIUtils.BORDER_COLOR));

        JPanel logoPanel = new JPanel();
        logoPanel.setLayout(new BoxLayout(logoPanel, BoxLayout.Y_AXIS));
        logoPanel.setBackground(UIUtils.BG_CARD);
        logoPanel.setBorder(new EmptyBorder(24, 20, 16, 20));

        JLabel logoText = new JLabel("Supermercado");
        logoText.setFont(new Font("Segoe UI", Font.BOLD, 16));
        logoText.setForeground(UIUtils.GREEN);
        logoText.setAlignmentX(LEFT_ALIGNMENT);

        JLabel logoSub = new JLabel("Panel de Administración");
        logoSub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        logoSub.setForeground(UIUtils.TEXT_MUTED);
        logoSub.setAlignmentX(LEFT_ALIGNMENT);

        logoPanel.add(logoText);
        logoPanel.add(Box.createVerticalStrut(4));
        logoPanel.add(logoSub);

        JSeparator sep1 = new JSeparator();
        sep1.setForeground(UIUtils.BORDER_COLOR);
        sep1.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));

        JLabel lblNav = new JLabel("MENÚ PRINCIPAL");
        lblNav.setFont(new Font("Segoe UI", Font.BOLD, 10));
        lblNav.setForeground(UIUtils.TEXT_MUTED);
        lblNav.setBorder(new EmptyBorder(14, 20, 6, 20));
        lblNav.setAlignmentX(LEFT_ALIGNMENT);

        JButton btnProductos   = crearNavBtn("Productos",   P_PRODUCTOS);
        JButton btnUsuarios    = crearNavBtn("Usuarios",    P_USUARIOS);
        JButton btnProveedores = crearNavBtn("Proveedores", P_PROVEEDORES);
        JButton btnMovimientos = crearNavBtn("Movimientos", P_MOVIMIENTOS);

        JSeparator sep2 = new JSeparator();
        sep2.setForeground(UIUtils.BORDER_COLOR);
        sep2.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));

        JPanel adminPanel = new JPanel();
        adminPanel.setLayout(new BoxLayout(adminPanel, BoxLayout.Y_AXIS));
        adminPanel.setBackground(new Color(20, 22, 32));
        adminPanel.setBorder(new EmptyBorder(12, 16, 12, 16));

        JLabel lblAdmin = new JLabel(adminName);
        lblAdmin.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblAdmin.setForeground(UIUtils.TEXT_PRIMARY);
        lblAdmin.setAlignmentX(LEFT_ALIGNMENT);

        JLabel lblRol = new JLabel("Administrador");
        lblRol.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblRol.setForeground(UIUtils.GREEN);
        lblRol.setAlignmentX(LEFT_ALIGNMENT);

        JButton btnLogout = UIUtils.crearBoton("Cerrar Sesión", new Color(40, 30, 30), UIUtils.RED);
        btnLogout.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnLogout.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        btnLogout.setAlignmentX(LEFT_ALIGNMENT);
        btnLogout.addActionListener(e -> cerrarSesion());

        adminPanel.add(lblAdmin);
        adminPanel.add(Box.createVerticalStrut(2));
        adminPanel.add(lblRol);
        adminPanel.add(Box.createVerticalStrut(10));
        adminPanel.add(btnLogout);

        sidebar.add(logoPanel);
        sidebar.add(sep1);
        sidebar.add(lblNav);
        sidebar.add(btnProductos);
        sidebar.add(btnUsuarios);
        sidebar.add(btnProveedores);
        sidebar.add(btnMovimientos);
        sidebar.add(Box.createVerticalGlue());
        sidebar.add(sep2);
        sidebar.add(adminPanel);

        // ── CONTENIDO ─────────────────────────────────────────────────────────
        cardLayout  = new CardLayout();
        contentArea = new JPanel(cardLayout);
        contentArea.setBackground(UIUtils.BG_PANEL);

        contentArea.add(new ProductosPanel(),   P_PRODUCTOS);
        contentArea.add(new UsuariosPanel(),    P_USUARIOS);
        contentArea.add(new ProveedoresPanel(), P_PROVEEDORES);
        contentArea.add(new MovimientosPanel(), P_MOVIMIENTOS);

        add(sidebar, BorderLayout.WEST);
        add(contentArea, BorderLayout.CENTER);

        setNavActivo(btnProductos);
    }

    private JButton crearNavBtn(String texto, final String panel) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setForeground(UIUtils.TEXT_LABEL);
        btn.setBackground(UIUtils.BG_CARD);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(new EmptyBorder(10, 20, 10, 20));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                if (btn != btnActivo) btn.setBackground(new Color(35, 38, 52));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                if (btn != btnActivo) btn.setBackground(UIUtils.BG_CARD);
            }
        });

        btn.addActionListener(e -> {
            cardLayout.show(contentArea, panel);
            setNavActivo(btn);
        });

        return btn;
    }

    private void setNavActivo(JButton btn) {
        if (btnActivo != null) {
            btnActivo.setBackground(UIUtils.BG_CARD);
            btnActivo.setForeground(UIUtils.TEXT_LABEL);
            btnActivo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        }
        btnActivo = btn;
        btn.setBackground(new Color(30, 50, 40));
        btn.setForeground(UIUtils.GREEN);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
    }

    private void cerrarSesion() {
        int ok = JOptionPane.showConfirmDialog(this,
            "¿Desea cerrar sesión?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (ok != JOptionPane.YES_OPTION) return;
        ApiClient.logout();
        dispose();
        SwingUtilities.invokeLater(() -> {
            JFrame lf = new JFrame("Supermercado — Login");
            lf.setDefaultCloseOperation(EXIT_ON_CLOSE);
            lf.setSize(480, 540);
            lf.setLocationRelativeTo(null);
            lf.add(new LoginPanel(name -> {
                lf.dispose();
                new MainFrame(name).setVisible(true);
            }));
            lf.setVisible(true);
        });
    }
}

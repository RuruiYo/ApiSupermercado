package administrador.ui.dialogs;

import administrador.models.CategoriaDTO;
import administrador.models.ProductoDTO;
import administrador.models.UbicacionDTO;
import administrador.services.ApiClient;
import administrador.ui.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductoDialog extends JDialog {

    private boolean saved = false;
    private final ProductoDTO producto;

    private JTextField txtSku, txtNombre, txtDescripcion, txtPrecio, txtImagen;
    private JComboBox cmbCategoria;
    private JComboBox cmbUbicacion;

    public ProductoDialog(Window owner, ProductoDTO producto,
                          List categorias, List ubicaciones) {
        super(owner,
              producto == null ? "Nuevo Producto" : "Editar Producto",
              ModalityType.APPLICATION_MODAL);
        this.producto = producto;
        setSize(500, 600);
        setLocationRelativeTo(owner);
        setResizable(false);
        getContentPane().setBackground(UIUtils.BG_CARD);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UIUtils.BG_CARD);
        panel.setBorder(new EmptyBorder(28, 32, 24, 32));

        JLabel titulo = new JLabel(producto == null ? "Nuevo Producto" : "Editar Producto");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 17));
        titulo.setForeground(UIUtils.TEXT_PRIMARY);
        titulo.setAlignmentX(LEFT_ALIGNMENT);
        panel.add(titulo);
        panel.add(Box.createVerticalStrut(18));

        txtSku = addCampo(panel, "SKU / Código Interno *",
                producto != null ? producto.sKU_CodigoInterno : "");
        txtNombre = addCampo(panel, "Nombre del Producto *",
                producto != null ? producto.nombreProducto : "");
        txtDescripcion = addCampo(panel, "Descripción (opcional)",
                producto != null && producto.descripcion != null ? producto.descripcion : "");
        txtPrecio = addCampo(panel, "Precio de Venta ($) *",
                producto != null ? String.valueOf(producto.precioVenta) : "");
        txtImagen = addCampo(panel, "URL de Imagen (opcional)",
                producto != null && producto.imagenUrl != null ? producto.imagenUrl : "");

        if (producto != null) {
            txtSku.setEditable(false);
            txtSku.setBackground(UIUtils.BG_INPUT);
            txtSku.setForeground(new Color(148, 163, 184)); // TEXT_MUTED visible
            txtSku.setDisabledTextColor(new Color(148, 163, 184));
        }

        // ── Combobox Categoría ────────────────────────────────────────────────
        panel.add(UIUtils.crearLabel("Categoría *"));
        panel.add(Box.createVerticalStrut(5));
        cmbCategoria = new JComboBox();
        estilizarCombo(cmbCategoria);
        if (categorias != null && !categorias.isEmpty()) {
            for (Object c : categorias) {
                cmbCategoria.addItem(c);
                if (producto != null && c instanceof CategoriaDTO) {
                    CategoriaDTO cat = (CategoriaDTO) c;
                    if (cat.iD_Categoria == producto.iD_Categoria)
                        cmbCategoria.setSelectedItem(c);
                }
            }
        } else {
            cmbCategoria.addItem("(Sin categorías — revisar API)");
        }
        panel.add(cmbCategoria);
        panel.add(Box.createVerticalStrut(12));

        // ── Combobox Ubicación ────────────────────────────────────────────────
        panel.add(UIUtils.crearLabel("Ubicación en Bodega *"));
        panel.add(Box.createVerticalStrut(5));
        cmbUbicacion = new JComboBox();
        estilizarCombo(cmbUbicacion);
        if (ubicaciones != null && !ubicaciones.isEmpty()) {
            for (Object u : ubicaciones) {
                cmbUbicacion.addItem(u);
                if (producto != null && u instanceof UbicacionDTO) {
                    UbicacionDTO ubic = (UbicacionDTO) u;
                    if (ubic.iD_Ubicacion == producto.iD_Ubicacion)
                        cmbUbicacion.setSelectedItem(u);
                }
            }
        } else {
            cmbUbicacion.addItem("(Sin ubicaciones — ejecutar SQL primero)");
        }
        panel.add(cmbUbicacion);
        panel.add(Box.createVerticalStrut(24));

        // ── Botones ───────────────────────────────────────────────────────────
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setOpaque(false);
        btnRow.setAlignmentX(LEFT_ALIGNMENT);

        JButton btnCancelar = UIUtils.crearBoton("Cancelar", UIUtils.BORDER_COLOR, UIUtils.TEXT_LABEL);
        JButton btnGuardar  = UIUtils.crearBoton(
                producto == null ? "Crear Producto" : "Guardar Cambios",
                UIUtils.GREEN, UIUtils.BG_DARK);
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 13));

        btnCancelar.addActionListener(e -> dispose());
        btnGuardar.addActionListener(e -> guardar());

        btnRow.add(btnCancelar);
        btnRow.add(btnGuardar);
        panel.add(btnRow);

        add(panel);
    }

    private void guardar() {
        String nombre    = txtNombre.getText().trim();
        String precioStr = txtPrecio.getText().trim().replace(",", ".");

        if (nombre.isEmpty() || precioStr.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Complete los campos obligatorios (*).",
                    "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Object selCat  = cmbCategoria.getSelectedItem();
        Object selUbic = cmbUbicacion.getSelectedItem();

        if (!(selCat instanceof CategoriaDTO)) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione una categoría válida.", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!(selUbic instanceof UbicacionDTO)) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione una ubicación válida.", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double precio;
        try {
            precio = Double.parseDouble(precioStr);
            if (precio <= 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "El precio debe ser un número mayor a 0.",
                    "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        final CategoriaDTO cat   = (CategoriaDTO) selCat;
        final UbicacionDTO  ubic = (UbicacionDTO)  selUbic;

        final Map body = new HashMap();
        body.put("nombreProducto", nombre);
        body.put("descripcion",
                txtDescripcion.getText().trim().isEmpty() ? null : txtDescripcion.getText().trim());
        body.put("precioVenta", precio);
        body.put("imagenUrl",
                txtImagen.getText().trim().isEmpty() ? null : txtImagen.getText().trim());
        body.put("iD_Categoria", cat.iD_Categoria);
        body.put("iD_Ubicacion", ubic.iD_Ubicacion);
        if (producto == null) body.put("sKU_CodigoInterno", txtSku.getText().trim());

        new SwingWorker() {
            String error = null;
            protected Object doInBackground() throws Exception {
                ApiClient.ApiResponse resp = producto == null
                        ? ApiClient.post("/productos", body)
                        : ApiClient.put("/productos/" + producto.iD_Producto, body);
                if (!resp.isOk()) error = resp.getMensajeError();
                return null;
            }
            protected void done() {
                if (error != null) {
                    JOptionPane.showMessageDialog(ProductoDialog.this,
                            error, "Error al guardar", JOptionPane.ERROR_MESSAGE);
                } else {
                    saved = true;
                    JOptionPane.showMessageDialog(ProductoDialog.this,
                            producto == null ? "Producto creado correctamente."
                                             : "Producto actualizado correctamente.",
                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                }
            }
        }.execute();
    }

    private JTextField addCampo(JPanel panel, String label, String valor) {
        JLabel lbl = UIUtils.crearLabel(label);
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        JTextField txt = UIUtils.crearTextField("");
        txt.setText(valor);
        txt.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        txt.setAlignmentX(LEFT_ALIGNMENT);
        panel.add(lbl);
        panel.add(Box.createVerticalStrut(5));
        panel.add(txt);
        panel.add(Box.createVerticalStrut(11));
        return txt;
    }

    private void estilizarCombo(JComboBox cmb) {
        cmb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmb.setBackground(UIUtils.BG_INPUT);
        cmb.setForeground(UIUtils.TEXT_PRIMARY);
        cmb.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        cmb.setAlignmentX(LEFT_ALIGNMENT);
    }

    public boolean isSaved() { return saved; }
}

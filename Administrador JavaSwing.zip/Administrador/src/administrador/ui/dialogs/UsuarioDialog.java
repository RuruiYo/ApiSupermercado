package administrador.ui.dialogs;

import administrador.services.ApiClient;
import administrador.ui.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class UsuarioDialog extends JDialog {

    private boolean saved = false;
    private JTextField txtNombre, txtCorreo;
    private JPasswordField txtPassword;
    private JComboBox<String> cmbRol;

    public UsuarioDialog(Window owner) {
        super(owner, "➕ Nuevo Usuario", ModalityType.APPLICATION_MODAL);
        setSize(440, 420);
        setLocationRelativeTo(owner);
        setResizable(false);
        getContentPane().setBackground(UIUtils.BG_CARD);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UIUtils.BG_CARD);
        panel.setBorder(new EmptyBorder(28, 32, 28, 32));

        JLabel titulo = new JLabel("Nuevo Usuario del Sistema");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 17));
        titulo.setForeground(UIUtils.TEXT_PRIMARY);
        titulo.setAlignmentX(LEFT_ALIGNMENT);
        panel.add(titulo);
        panel.add(Box.createVerticalStrut(20));

        txtNombre   = addCampo(panel, "Nombre Completo *", "");
        txtCorreo   = addCampo(panel, "Correo Electrónico *", "");
        txtPassword = addPasswordField(panel, "Contraseña *");

        JLabel lblRol = UIUtils.crearLabel("Rol *");
        lblRol.setAlignmentX(LEFT_ALIGNMENT);
        cmbRol = new JComboBox<>(new String[]{"Bodeguero", "Cajero"});
        cmbRol.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbRol.setBackground(UIUtils.BG_INPUT);
        cmbRol.setForeground(UIUtils.TEXT_PRIMARY);
        cmbRol.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        cmbRol.setAlignmentX(LEFT_ALIGNMENT);
        panel.add(lblRol);
        panel.add(Box.createVerticalStrut(5));
        panel.add(cmbRol);
        panel.add(Box.createVerticalStrut(24));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setOpaque(false);
        btnRow.setAlignmentX(LEFT_ALIGNMENT);

        JButton btnCancelar = UIUtils.crearBoton("Cancelar", UIUtils.BORDER_COLOR, UIUtils.TEXT_LABEL);
        JButton btnGuardar  = UIUtils.crearBoton("Crear Usuario", UIUtils.GREEN, UIUtils.BG_DARK);
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 13));

        btnCancelar.addActionListener(e -> dispose());
        btnGuardar.addActionListener(e -> guardar());

        btnRow.add(btnCancelar);
        btnRow.add(btnGuardar);
        panel.add(btnRow);

        add(panel);
    }

    private void guardar() {
        String nombre = txtNombre.getText().trim();
        String correo = txtCorreo.getText().trim();
        String pass   = new String(txtPassword.getPassword()).trim();
        String rolStr = (String) cmbRol.getSelectedItem();

        if (nombre.isEmpty() || correo.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Complete todos los campos obligatorios (*).", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (pass.length() < 6) {
            JOptionPane.showMessageDialog(this, "La contraseña debe tener al menos 6 caracteres.", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Bodeguero = ID 2, Cajero = ID 3 según datos base
        int idRol = "Bodeguero".equals(rolStr) ? 2 : 3;

        Map<String, Object> body = new HashMap<>();
        body.put("nombreCompleto", nombre);
        body.put("correo_Usuario", correo);
        body.put("contrasena", pass);
        body.put("iD_Rol", idRol);

        new SwingWorker<Void, Void>() {
            String error = null;
            @Override protected Void doInBackground() throws Exception {
                ApiClient.ApiResponse resp = ApiClient.post("/usuarios", body);
                if (!resp.isOk()) error = ApiClient.getMensaje(resp.body);
                return null;
            }
            @Override protected void done() {
                if (error != null) {
                    JOptionPane.showMessageDialog(UsuarioDialog.this, error, "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    saved = true;
                    JOptionPane.showMessageDialog(UsuarioDialog.this, "Usuario creado correctamente ✔", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                }
            }
        }.execute();
    }

    private JTextField addCampo(JPanel panel, String label, String valor) {
        JLabel lbl = UIUtils.crearLabel(label);
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        JTextField txt = UIUtils.crearTextField("");
        txt.setText(valor);
        txt.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        txt.setAlignmentX(LEFT_ALIGNMENT);
        panel.add(lbl);
        panel.add(Box.createVerticalStrut(5));
        panel.add(txt);
        panel.add(Box.createVerticalStrut(11));
        return txt;
    }

    private JPasswordField addPasswordField(JPanel panel, String label) {
        JLabel lbl = UIUtils.crearLabel(label);
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        JPasswordField txt = UIUtils.crearPasswordField();
        txt.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        txt.setAlignmentX(LEFT_ALIGNMENT);
        panel.add(lbl);
        panel.add(Box.createVerticalStrut(5));
        panel.add(txt);
        panel.add(Box.createVerticalStrut(11));
        return txt;
    }

    public boolean isSaved() { return saved; }
}

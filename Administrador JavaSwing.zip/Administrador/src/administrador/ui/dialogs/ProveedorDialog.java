package administrador.ui.dialogs;

import administrador.services.ApiClient;
import administrador.ui.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class ProveedorDialog extends JDialog {

    private boolean saved = false;
    private JTextField txtNombre, txtContacto, txtTelefono;

    public ProveedorDialog(Window owner) {
        super(owner, "Nuevo Proveedor", ModalityType.APPLICATION_MODAL);
        setSize(430, 360);
        setLocationRelativeTo(owner);
        setResizable(false);
        getContentPane().setBackground(UIUtils.BG_CARD);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UIUtils.BG_CARD);
        panel.setBorder(new EmptyBorder(28, 32, 28, 32));

        JLabel titulo = new JLabel("Nuevo Proveedor");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 17));
        titulo.setForeground(UIUtils.TEXT_PRIMARY);
        titulo.setAlignmentX(LEFT_ALIGNMENT);
        panel.add(titulo);
        panel.add(Box.createVerticalStrut(18));

        txtNombre   = addCampo(panel, "Nombre de la Empresa *", "");
        txtContacto = addCampo(panel, "Persona de Contacto (opcional)", "");
        txtTelefono = addCampo(panel, "Teléfono (opcional)", "");

        panel.add(Box.createVerticalStrut(8));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setOpaque(false);
        btnRow.setAlignmentX(LEFT_ALIGNMENT);

        JButton btnCancelar = UIUtils.crearBoton("Cancelar", UIUtils.BORDER_COLOR, UIUtils.TEXT_LABEL);
        JButton btnGuardar  = UIUtils.crearBoton("Crear Proveedor", UIUtils.GREEN, UIUtils.BG_DARK);
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 13));

        btnCancelar.addActionListener(e -> dispose());
        btnGuardar.addActionListener(e -> guardar());

        btnRow.add(btnCancelar);
        btnRow.add(btnGuardar);
        panel.add(btnRow);

        add(panel);
    }

    private void guardar() {
        String nombre = txtNombre.getText().trim();
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "El nombre de la empresa es obligatorio.",
                    "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }

        final Map body = new HashMap();
        body.put("nombreEmpresa", nombre);
        body.put("contactoAsignado",
                txtContacto.getText().trim().isEmpty() ? null : txtContacto.getText().trim());
        body.put("telefono",
                txtTelefono.getText().trim().isEmpty() ? null : txtTelefono.getText().trim());

        new SwingWorker() {
            String error = null;
            protected Object doInBackground() throws Exception {
                ApiClient.ApiResponse resp = ApiClient.post("/proveedores", body);
                if (!resp.isOk()) error = resp.getMensajeError();
                return null;
            }
            protected void done() {
                if (error != null) {
                    JOptionPane.showMessageDialog(ProveedorDialog.this,
                            error, "Error al guardar", JOptionPane.ERROR_MESSAGE);
                } else {
                    saved = true;
                    JOptionPane.showMessageDialog(ProveedorDialog.this,
                            "Proveedor creado correctamente.",
                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                }
            }
        }.execute();
    }

    private JTextField addCampo(JPanel panel, String label, String valor) {
        JLabel lbl = UIUtils.crearLabel(label);
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        JTextField txt = UIUtils.crearTextField("");
        txt.setText(valor);
        txt.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        txt.setAlignmentX(LEFT_ALIGNMENT);
        panel.add(lbl);
        panel.add(Box.createVerticalStrut(5));
        panel.add(txt);
        panel.add(Box.createVerticalStrut(11));
        return txt;
    }

    public boolean isSaved() { return saved; }
}

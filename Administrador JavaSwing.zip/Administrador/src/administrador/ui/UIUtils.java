package administrador.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;

public class UIUtils {

    public static final Color BG_DARK      = new Color(18, 20, 28);
    public static final Color BG_PANEL     = new Color(24, 26, 36);
    public static final Color BG_CARD      = new Color(32, 34, 46);
    public static final Color BG_INPUT     = new Color(15, 17, 24);
    public static final Color BG_ROW_ALT   = new Color(22, 24, 34);
    public static final Color BG_SELECTED  = new Color(45, 55, 72);
    public static final Color BORDER_COLOR = new Color(48, 51, 68);

    public static final Color TEXT_PRIMARY = new Color(226, 232, 240);
    public static final Color TEXT_MUTED   = new Color(100, 116, 139);
    public static final Color TEXT_LABEL   = new Color(148, 163, 184);

    public static final Color GREEN  = new Color(74, 222, 128);
    public static final Color RED    = new Color(239, 68, 68);
    public static final Color BLUE   = new Color(96, 165, 250);
    public static final Color ORANGE = new Color(251, 146, 60);
    public static final Color YELLOW = new Color(250, 204, 21);

    public static JButton crearBoton(String texto, Color bg, Color fg) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(new EmptyBorder(8, 16, 8, 16));
        return btn;
    }

    public static JTextField crearTextField(String placeholder) {
        JTextField txt = new JTextField();
        txt.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txt.setBackground(BG_INPUT);
        txt.setForeground(TEXT_PRIMARY);
        txt.setCaretColor(TEXT_PRIMARY);
        txt.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(6, 10, 6, 10)));
        return txt;
    }

    public static JPasswordField crearPasswordField() {
        JPasswordField txt = new JPasswordField();
        txt.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txt.setBackground(BG_INPUT);
        txt.setForeground(TEXT_PRIMARY);
        txt.setCaretColor(TEXT_PRIMARY);
        txt.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                new EmptyBorder(6, 10, 6, 10)));
        return txt;
    }

    public static JLabel crearLabel(String texto) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setForeground(TEXT_LABEL);
        return lbl;
    }

    public static void estilizarTabla(JTable tabla) {
        tabla.setBackground(BG_DARK);
        tabla.setForeground(TEXT_PRIMARY);
        tabla.setGridColor(BORDER_COLOR);
        tabla.setRowHeight(34);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabla.setSelectionBackground(BG_SELECTED);
        tabla.setSelectionForeground(Color.WHITE);
        tabla.setShowVerticalLines(false);
        tabla.setIntercellSpacing(new Dimension(0, 1));
        tabla.setFillsViewportHeight(true);

        JTableHeader header = tabla.getTableHeader();
        header.setBackground(BG_CARD);
        header.setForeground(TEXT_MUTED);
        header.setFont(new Font("Segoe UI", Font.BOLD, 12));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, BORDER_COLOR));
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 38));

        tabla.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                setBackground(sel ? BG_SELECTED : (row % 2 == 0 ? BG_DARK : BG_ROW_ALT));
                setForeground(TEXT_PRIMARY);
                setBorder(new EmptyBorder(0, 12, 0, 12));
                return this;
            }
        });
        tabla.setDefaultRenderer(Integer.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                setHorizontalAlignment(CENTER);
                setBackground(sel ? BG_SELECTED : (row % 2 == 0 ? BG_DARK : BG_ROW_ALT));
                setForeground(TEXT_PRIMARY);
                return this;
            }
        });
        tabla.setDefaultRenderer(Double.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                String txt = v != null ? String.format("$%.2f", (Double) v) : "";
                super.getTableCellRendererComponent(t, txt, sel, foc, row, col);
                setHorizontalAlignment(RIGHT);
                setBackground(sel ? BG_SELECTED : (row % 2 == 0 ? BG_DARK : BG_ROW_ALT));
                setForeground(GREEN);
                setBorder(new EmptyBorder(0, 8, 0, 12));
                return this;
            }
        });
    }

    public static TableCellRenderer estadoRenderer() {
        return new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                setHorizontalAlignment(CENTER);
                boolean activo = "Activo".equals(v != null ? v.toString() : "");
                setText(activo ? "● Activo" : "● Inactivo");
                setForeground(activo ? GREEN : RED);
                setBackground(sel ? BG_SELECTED : (row % 2 == 0 ? BG_DARK : BG_ROW_ALT));
                setFont(new Font("Segoe UI", Font.BOLD, 12));
                return this;
            }
        };
    }

    public static TableCellRenderer tipoMovimientoRenderer() {
        return new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                String tipo = v != null ? v.toString() : "";
                setHorizontalAlignment(CENTER);
                setFont(new Font("Segoe UI", Font.BOLD, 11));
                setBackground(sel ? BG_SELECTED : (row % 2 == 0 ? BG_DARK : BG_ROW_ALT));
                if ("ENTRADA_LOTE".equals(tipo))      setForeground(GREEN);
                else if ("TRASLADO_ESTANTE".equals(tipo)) setForeground(BLUE);
                else if ("DESCARTE".equals(tipo))     setForeground(RED);
                else if ("VENTA".equals(tipo))        setForeground(ORANGE);
                else                                  setForeground(TEXT_PRIMARY);
                return this;
            }
        };
    }
}

package administrador.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.*;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.nio.charset.StandardCharsets;

public class ApiClient {

    private static final String BASE_URL = "http://localhost:5153/api";
    private static String token = null;

    // Gson con serializeNulls y sin política especial de nombres:
    // los @SerializedName en los DTOs se encargan del mapeo exacto
    private static final Gson gson = new GsonBuilder()
            .serializeNulls()
            .create();

    public static void setToken(String t) { token = t; }
    public static void logout()           { token = null; }
    public static boolean isAuthenticated() { return token != null; }

    // ── GET ───────────────────────────────────────────────────────────────────
    public static String get(String endpoint) throws Exception {
        CloseableHttpClient client = HttpClients.createDefault();
        try {
            HttpGet req = new HttpGet(BASE_URL + endpoint);
            req.setHeader("Content-Type", "application/json");
            if (token != null) req.setHeader("Authorization", "Bearer " + token);
            CloseableHttpResponse resp = client.execute(req);
            try {
                return EntityUtils.toString(resp.getEntity(), StandardCharsets.UTF_8);
            } finally { resp.close(); }
        } finally { client.close(); }
    }

    // ── POST sin auth (login) ─────────────────────────────────────────────────
    public static ApiResponse postPublic(String endpoint, Object body) throws Exception {
        CloseableHttpClient client = HttpClients.createDefault();
        try {
            HttpPost req = new HttpPost(BASE_URL + endpoint);
            req.setHeader("Content-Type", "application/json");
            req.setEntity(new StringEntity(gson.toJson(body), StandardCharsets.UTF_8));
            CloseableHttpResponse resp = client.execute(req);
            try {
                return new ApiResponse(
                    resp.getStatusLine().getStatusCode(),
                    EntityUtils.toString(resp.getEntity(), StandardCharsets.UTF_8));
            } finally { resp.close(); }
        } finally { client.close(); }
    }

    // ── POST con auth ─────────────────────────────────────────────────────────
    public static ApiResponse post(String endpoint, Object body) throws Exception {
        CloseableHttpClient client = HttpClients.createDefault();
        try {
            HttpPost req = new HttpPost(BASE_URL + endpoint);
            req.setHeader("Content-Type", "application/json");
            req.setHeader("Authorization", "Bearer " + token);
            req.setEntity(new StringEntity(gson.toJson(body), StandardCharsets.UTF_8));
            CloseableHttpResponse resp = client.execute(req);
            try {
                return new ApiResponse(
                    resp.getStatusLine().getStatusCode(),
                    EntityUtils.toString(resp.getEntity(), StandardCharsets.UTF_8));
            } finally { resp.close(); }
        } finally { client.close(); }
    }

    // ── PUT ───────────────────────────────────────────────────────────────────
    public static ApiResponse put(String endpoint, Object body) throws Exception {
        CloseableHttpClient client = HttpClients.createDefault();
        try {
            HttpPut req = new HttpPut(BASE_URL + endpoint);
            req.setHeader("Content-Type", "application/json");
            req.setHeader("Authorization", "Bearer " + token);
            req.setEntity(new StringEntity(gson.toJson(body), StandardCharsets.UTF_8));
            CloseableHttpResponse resp = client.execute(req);
            try {
                return new ApiResponse(
                    resp.getStatusLine().getStatusCode(),
                    EntityUtils.toString(resp.getEntity(), StandardCharsets.UTF_8));
            } finally { resp.close(); }
        } finally { client.close(); }
    }

    // ── DELETE ────────────────────────────────────────────────────────────────
    public static ApiResponse delete(String endpoint) throws Exception {
        CloseableHttpClient client = HttpClients.createDefault();
        try {
            org.apache.http.client.methods.HttpDelete req =
                new org.apache.http.client.methods.HttpDelete(BASE_URL + endpoint);
            req.setHeader("Content-Type", "application/json");
            if (token != null) req.setHeader("Authorization", "Bearer " + token);
            CloseableHttpResponse resp = client.execute(req);
            try {
                return new ApiResponse(
                    resp.getStatusLine().getStatusCode(),
                    EntityUtils.toString(resp.getEntity(), StandardCharsets.UTF_8));
            } finally { resp.close(); }
        } finally { client.close(); }
    }

    // ── PATCH ─────────────────────────────────────────────────────────────────
    public static ApiResponse patch(String endpoint, Object body) throws Exception {
        CloseableHttpClient client = HttpClients.createDefault();
        try {
            HttpPatch req = new HttpPatch(BASE_URL + endpoint);
            req.setHeader("Content-Type", "application/json");
            req.setHeader("Authorization", "Bearer " + token);
            req.setEntity(new StringEntity(gson.toJson(body), StandardCharsets.UTF_8));
            CloseableHttpResponse resp = client.execute(req);
            try {
                return new ApiResponse(
                    resp.getStatusLine().getStatusCode(),
                    EntityUtils.toString(resp.getEntity(), StandardCharsets.UTF_8));
            } finally { resp.close(); }
        } finally { client.close(); }
    }

    // ── Extrae mensaje legible del JSON de error ──────────────────────────────
    public static String getMensaje(String json) {
        if (json == null || json.trim().isEmpty())
            return "Sin respuesta del servidor.";
        try {
            JsonObject obj = new JsonParser().parse(json).getAsJsonObject();
            if (obj.has("mensaje") && !obj.get("mensaje").isJsonNull())
                return obj.get("mensaje").getAsString();
            if (obj.has("errors") && obj.get("errors").isJsonObject()) {
                JsonObject errors = obj.getAsJsonObject("errors");
                StringBuilder sb = new StringBuilder();
                for (String key : errors.keySet()) {
                    JsonArray arr = errors.getAsJsonArray(key);
                    for (int i = 0; i < arr.size(); i++) {
                        if (sb.length() > 0) sb.append("\n");
                        sb.append(arr.get(i).getAsString());
                    }
                }
                if (sb.length() > 0) return sb.toString();
            }
            if (obj.has("title") && !obj.get("title").isJsonNull())
                return obj.get("title").getAsString();
            if (obj.has("detalle") && !obj.get("detalle").isJsonNull())
                return obj.get("detalle").getAsString();
        } catch (Exception ignored) {
            if (json.length() <= 300) return json;
        }
        return "Error inesperado del servidor.";
    }

    public static Gson getGson() { return gson; }

    // ── Clase interna de respuesta ────────────────────────────────────────────
    public static class ApiResponse {
        public final int    status;
        public final String body;

        public ApiResponse(int s, String b) { status = s; body = b; }

        public boolean isOk() { return status >= 200 && status < 300; }

        public String getMensajeError() {
            String msg = getMensaje(body);
            switch (status) {
                case 400: return "Datos inválidos:\n" + msg;
                case 401: return "No autorizado:\n" + msg;
                case 403: return "Sin permisos:\n" + msg;
                case 404: return "No encontrado:\n" + msg;
                case 409: return "Conflicto:\n" + msg;
                case 422: return "Error de validación:\n" + msg;
                case 500: return "Error del servidor:\n" + msg;
                default:  return "Error " + status + ":\n" + msg;
            }
        }
    }
}

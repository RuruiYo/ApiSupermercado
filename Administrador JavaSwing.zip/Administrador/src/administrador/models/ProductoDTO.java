package administrador.models;

import com.google.gson.annotations.SerializedName;

public class ProductoDTO {
    @SerializedName(value = "iD_Producto",   alternate = {"ID_Producto", "id_Producto"})
    public int    iD_Producto;

    @SerializedName(value = "skU_CodigoInterno", alternate = {"sKU_CodigoInterno", "SKU_CodigoInterno", "sku_CodigoInterno"})
    public String sKU_CodigoInterno;

    @SerializedName(value = "nombreProducto", alternate = {"NombreProducto"})
    public String nombreProducto;

    @SerializedName(value = "descripcion", alternate = {"Descripcion"})
    public String descripcion;

    @SerializedName(value = "precioVenta", alternate = {"PrecioVenta"})
    public double precioVenta;

    @SerializedName(value = "stock_Bodega_Total",    alternate = {"Stock_Bodega_Total"})
    public int    stock_Bodega_Total;

    @SerializedName(value = "stock_Estante_Total",   alternate = {"Stock_Estante_Total"})
    public int    stock_Estante_Total;

    @SerializedName(value = "stock_Reservado_Total", alternate = {"Stock_Reservado_Total"})
    public int    stock_Reservado_Total;

    @SerializedName(value = "imagenUrl", alternate = {"ImagenUrl"})
    public String imagenUrl;

    @SerializedName(value = "nombreCategoria", alternate = {"NombreCategoria"})
    public String nombreCategoria;

    @SerializedName(value = "iD_Categoria", alternate = {"ID_Categoria", "id_Categoria"})
    public int    iD_Categoria;

    @SerializedName(value = "nombreUbicacion", alternate = {"NombreUbicacion"})
    public String nombreUbicacion;

    @SerializedName(value = "iD_Ubicacion", alternate = {"ID_Ubicacion", "id_Ubicacion"})
    public int    iD_Ubicacion;

    @Override
    public String toString() { return nombreProducto; }
}
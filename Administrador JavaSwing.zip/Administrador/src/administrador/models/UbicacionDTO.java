package administrador.models;

public class UbicacionDTO {
    public int    iD_Ubicacion;
    public String nombreUbicacion;
    public int    totalProductos;

    @Override
    public String toString() {
        return totalProductos > 0
                ? nombreUbicacion + " (" + totalProductos + " productos)"
                : nombreUbicacion;
    }
}

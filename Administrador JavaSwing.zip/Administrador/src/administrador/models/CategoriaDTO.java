package administrador.models;

public class CategoriaDTO {
    public int iD_Categoria;
    public String nombreCategoria;
    @Override public String toString() { return nombreCategoria; }
}

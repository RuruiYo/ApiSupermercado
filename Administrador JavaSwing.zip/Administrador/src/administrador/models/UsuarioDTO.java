package administrador.models;

public class UsuarioDTO {
    public int iD_Usuario;
    public String nombreCompleto;
    public String correo_Usuario;
    public boolean estadoActivo;
    public String nombreRol;
    @Override public String toString() { return nombreCompleto; }
}

package administrador.models;

public class MovimientoDTO {
    public int iD_Movimiento;
    public String fechaHora;
    public String tipoMovimiento;
    public int cantidadMovida;
    public String observaciones;
    public String nombreProducto;
    public String codigoLote;
    public String nombreUsuario;
}

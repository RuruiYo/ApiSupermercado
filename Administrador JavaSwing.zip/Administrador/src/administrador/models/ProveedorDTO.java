package administrador.models;

public class ProveedorDTO {
    public int iD_Proveedor;
    public String nombreEmpresa;
    public String contactoAsignado;
    public String telefono;
    public boolean estadoActivo;
    @Override public String toString() { return nombreEmpresa; }
}
